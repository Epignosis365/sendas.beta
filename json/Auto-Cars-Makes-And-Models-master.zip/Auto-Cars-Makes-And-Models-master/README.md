Auto-Cars-Makes-And-Models
==========================

JSON string, DB Dump, PHP Array of all cars makes and models

This list consists of 71 makes and over 1,300 different models.

Last Updated: 02/11/2012

You'll find a file with a JSON string, PHP array and an SQL dump of two tables (make & model)

This will allow to pretty much use the data in the easiest way for you whether it's using PHP, DB or JSON.

&copy; Vincent Gabriel @ http://vadimg.com 