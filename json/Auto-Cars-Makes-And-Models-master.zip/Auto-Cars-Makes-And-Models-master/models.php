<?php

return array (
  0 => 
  array (
    'value' => 'ACURA',
    'title' => 'Acura',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'CL_MODELS',
        'title' => 'CL Models (4)',
      ),
      1 => 
      array (
        'value' => '2.2CL',
        'title' => ' - 2.2CL',
      ),
      2 => 
      array (
        'value' => '2.3CL',
        'title' => ' - 2.3CL',
      ),
      3 => 
      array (
        'value' => '3.0CL',
        'title' => ' - 3.0CL',
      ),
      4 => 
      array (
        'value' => '3.2CL',
        'title' => ' - 3.2CL',
      ),
      5 => 
      array (
        'value' => 'ILX',
        'title' => 'ILX',
      ),
      6 => 
      array (
        'value' => 'INTEG',
        'title' => 'Integra',
      ),
      7 => 
      array (
        'value' => 'LEGEND',
        'title' => 'Legend',
      ),
      8 => 
      array (
        'value' => 'MDX',
        'title' => 'MDX',
      ),
      9 => 
      array (
        'value' => 'NSX',
        'title' => 'NSX',
      ),
      10 => 
      array (
        'value' => 'RDX',
        'title' => 'RDX',
      ),
      11 => 
      array (
        'value' => 'RL_MODELS',
        'title' => 'RL Models (2)',
      ),
      12 => 
      array (
        'value' => '3.5RL',
        'title' => ' - 3.5 RL',
      ),
      13 => 
      array (
        'value' => 'RL',
        'title' => ' - RL',
      ),
      14 => 
      array (
        'value' => 'RSX',
        'title' => 'RSX',
      ),
      15 => 
      array (
        'value' => 'SLX',
        'title' => 'SLX',
      ),
      16 => 
      array (
        'value' => 'TL_MODELS',
        'title' => 'TL Models (3)',
      ),
      17 => 
      array (
        'value' => '2.5TL',
        'title' => ' - 2.5TL',
      ),
      18 => 
      array (
        'value' => '3.2TL',
        'title' => ' - 3.2TL',
      ),
      19 => 
      array (
        'value' => 'TL',
        'title' => ' - TL',
      ),
      20 => 
      array (
        'value' => 'TSX',
        'title' => 'TSX',
      ),
      21 => 
      array (
        'value' => 'VIGOR',
        'title' => 'Vigor',
      ),
      22 => 
      array (
        'value' => 'ZDX',
        'title' => 'ZDX',
      ),
      23 => 
      array (
        'value' => 'ACUOTH',
        'title' => 'Other Acura Models',
      ),
    ),
  ),
  1 => 
  array (
    'value' => 'ALFA',
    'title' => 'Alfa Romeo',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ALFA164',
        'title' => '164',
      ),
      1 => 
      array (
        'value' => 'ALFA8C',
        'title' => '8C Competizione',
      ),
      2 => 
      array (
        'value' => 'ALFAGT',
        'title' => 'GTV-6',
      ),
      3 => 
      array (
        'value' => 'MIL',
        'title' => 'Milano',
      ),
      4 => 
      array (
        'value' => 'SPID',
        'title' => 'Spider',
      ),
      5 => 
      array (
        'value' => 'ALFAOTH',
        'title' => 'Other Alfa Romeo Models',
      ),
    ),
  ),
  2 => 
  array (
    'value' => 'AMC',
    'title' => 'AMC',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'AMCALLIAN',
        'title' => 'Alliance',
      ),
      1 => 
      array (
        'value' => 'CON',
        'title' => 'Concord',
      ),
      2 => 
      array (
        'value' => 'EAGLE',
        'title' => 'Eagle',
      ),
      3 => 
      array (
        'value' => 'AMCENC',
        'title' => 'Encore',
      ),
      4 => 
      array (
        'value' => 'AMCSPIRIT',
        'title' => 'Spirit',
      ),
      5 => 
      array (
        'value' => 'AMCOTH',
        'title' => 'Other AMC Models',
      ),
    ),
  ),
  3 => 
  array (
    'value' => 'ASTON',
    'title' => 'Aston Martin',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'DB7',
        'title' => 'DB7',
      ),
      1 => 
      array (
        'value' => 'DB9',
        'title' => 'DB9',
      ),
      2 => 
      array (
        'value' => 'DBS',
        'title' => 'DBS',
      ),
      3 => 
      array (
        'value' => 'LAGONDA',
        'title' => 'Lagonda',
      ),
      4 => 
      array (
        'value' => 'RAPIDE',
        'title' => 'Rapide',
      ),
      5 => 
      array (
        'value' => 'V12VANT',
        'title' => 'V12 Vantage',
      ),
      6 => 
      array (
        'value' => 'VANTAGE',
        'title' => 'V8 Vantage',
      ),
      7 => 
      array (
        'value' => 'VANQUISH',
        'title' => 'Vanquish',
      ),
      8 => 
      array (
        'value' => 'VIRAGE',
        'title' => 'Virage',
      ),
      9 => 
      array (
        'value' => 'UNAVAILAST',
        'title' => 'Other Aston Martin Models',
      ),
    ),
  ),
  4 => 
  array (
    'value' => 'AUDI',
    'title' => 'Audi',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'AUDI100',
        'title' => '100',
      ),
      1 => 
      array (
        'value' => 'AUDI200',
        'title' => '200',
      ),
      2 => 
      array (
        'value' => '4000',
        'title' => '4000',
      ),
      3 => 
      array (
        'value' => '5000',
        'title' => '5000',
      ),
      4 => 
      array (
        'value' => '80',
        'title' => '80',
      ),
      5 => 
      array (
        'value' => '90',
        'title' => '90',
      ),
      6 => 
      array (
        'value' => 'A3',
        'title' => 'A3',
      ),
      7 => 
      array (
        'value' => 'A4',
        'title' => 'A4',
      ),
      8 => 
      array (
        'value' => 'A5',
        'title' => 'A5',
      ),
      9 => 
      array (
        'value' => 'A6',
        'title' => 'A6',
      ),
      10 => 
      array (
        'value' => 'A7',
        'title' => 'A7',
      ),
      11 => 
      array (
        'value' => 'A8',
        'title' => 'A8',
      ),
      12 => 
      array (
        'value' => 'ALLRDQUA',
        'title' => 'allroad',
      ),
      13 => 
      array (
        'value' => 'AUDICABRI',
        'title' => 'Cabriolet',
      ),
      14 => 
      array (
        'value' => 'AUDICOUPE',
        'title' => 'Coupe',
      ),
      15 => 
      array (
        'value' => 'Q3',
        'title' => 'Q3',
      ),
      16 => 
      array (
        'value' => 'Q5',
        'title' => 'Q5',
      ),
      17 => 
      array (
        'value' => 'Q7',
        'title' => 'Q7',
      ),
      18 => 
      array (
        'value' => 'QUATTR',
        'title' => 'Quattro',
      ),
      19 => 
      array (
        'value' => 'R8',
        'title' => 'R8',
      ),
      20 => 
      array (
        'value' => 'RS4',
        'title' => 'RS 4',
      ),
      21 => 
      array (
        'value' => 'RS5',
        'title' => 'RS 5',
      ),
      22 => 
      array (
        'value' => 'RS6',
        'title' => 'RS 6',
      ),
      23 => 
      array (
        'value' => 'S4',
        'title' => 'S4',
      ),
      24 => 
      array (
        'value' => 'S5',
        'title' => 'S5',
      ),
      25 => 
      array (
        'value' => 'S6',
        'title' => 'S6',
      ),
      26 => 
      array (
        'value' => 'S7',
        'title' => 'S7',
      ),
      27 => 
      array (
        'value' => 'S8',
        'title' => 'S8',
      ),
      28 => 
      array (
        'value' => 'TT',
        'title' => 'TT',
      ),
      29 => 
      array (
        'value' => 'TTRS',
        'title' => 'TT RS',
      ),
      30 => 
      array (
        'value' => 'TTS',
        'title' => 'TTS',
      ),
      31 => 
      array (
        'value' => 'V8',
        'title' => 'V8 Quattro',
      ),
      32 => 
      array (
        'value' => 'AUDOTH',
        'title' => 'Other Audi Models',
      ),
    ),
  ),
  5 => 
  array (
    'value' => 'AVANTI',
    'title' => 'Avanti',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'CONVERT',
        'title' => 'Convertible',
      ),
      1 => 
      array (
        'value' => 'COUPEAVANT',
        'title' => 'Coupe',
      ),
      2 => 
      array (
        'value' => 'SEDAN',
        'title' => 'Sedan',
      ),
      3 => 
      array (
        'value' => 'UNAVAILAVA',
        'title' => 'Other Avanti Models',
      ),
    ),
  ),
  6 => 
  array (
    'value' => 'BENTL',
    'title' => 'Bentley',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ARNAGE',
        'title' => 'Arnage',
      ),
      1 => 
      array (
        'value' => 'AZURE',
        'title' => 'Azure',
      ),
      2 => 
      array (
        'value' => 'BROOKLANDS',
        'title' => 'Brooklands',
      ),
      3 => 
      array (
        'value' => 'BENCONT',
        'title' => 'Continental',
      ),
      4 => 
      array (
        'value' => 'CORNICHE',
        'title' => 'Corniche',
      ),
      5 => 
      array (
        'value' => 'BENEIGHT',
        'title' => 'Eight',
      ),
      6 => 
      array (
        'value' => 'BENMUL',
        'title' => 'Mulsanne',
      ),
      7 => 
      array (
        'value' => 'BENTURBO',
        'title' => 'Turbo R',
      ),
      8 => 
      array (
        'value' => 'UNAVAILBEN',
        'title' => 'Other Bentley Models',
      ),
    ),
  ),
  7 => 
  array (
    'value' => 'BMW',
    'title' => 'BMW',
    'models' => 
    array (
      0 => 
      array (
        'value' => '1_SERIES',
        'title' => '1 Series (3)',
      ),
      1 => 
      array (
        'value' => '128I',
        'title' => ' - 128i',
      ),
      2 => 
      array (
        'value' => '135I',
        'title' => ' - 135i',
      ),
      3 => 
      array (
        'value' => '135IS',
        'title' => ' - 135is',
      ),
      4 => 
      array (
        'value' => '3_SERIES',
        'title' => '3 Series (29)',
      ),
      5 => 
      array (
        'value' => '318I',
        'title' => ' - 318i',
      ),
      6 => 
      array (
        'value' => '318IC',
        'title' => ' - 318iC',
      ),
      7 => 
      array (
        'value' => '318IS',
        'title' => ' - 318iS',
      ),
      8 => 
      array (
        'value' => '318TI',
        'title' => ' - 318ti',
      ),
      9 => 
      array (
        'value' => '320I',
        'title' => ' - 320i',
      ),
      10 => 
      array (
        'value' => '323CI',
        'title' => ' - 323ci',
      ),
      11 => 
      array (
        'value' => '323I',
        'title' => ' - 323i',
      ),
      12 => 
      array (
        'value' => '323IS',
        'title' => ' - 323is',
      ),
      13 => 
      array (
        'value' => '323IT',
        'title' => ' - 323iT',
      ),
      14 => 
      array (
        'value' => '325CI',
        'title' => ' - 325Ci',
      ),
      15 => 
      array (
        'value' => '325E',
        'title' => ' - 325e',
      ),
      16 => 
      array (
        'value' => '325ES',
        'title' => ' - 325es',
      ),
      17 => 
      array (
        'value' => '325I',
        'title' => ' - 325i',
      ),
      18 => 
      array (
        'value' => '325IS',
        'title' => ' - 325is',
      ),
      19 => 
      array (
        'value' => '325IX',
        'title' => ' - 325iX',
      ),
      20 => 
      array (
        'value' => '325XI',
        'title' => ' - 325xi',
      ),
      21 => 
      array (
        'value' => '328CI',
        'title' => ' - 328Ci',
      ),
      22 => 
      array (
        'value' => '328I',
        'title' => ' - 328i',
      ),
      23 => 
      array (
        'value' => '328IS',
        'title' => ' - 328iS',
      ),
      24 => 
      array (
        'value' => '328XI',
        'title' => ' - 328xi',
      ),
      25 => 
      array (
        'value' => '330CI',
        'title' => ' - 330Ci',
      ),
      26 => 
      array (
        'value' => '330I',
        'title' => ' - 330i',
      ),
      27 => 
      array (
        'value' => '330XI',
        'title' => ' - 330xi',
      ),
      28 => 
      array (
        'value' => '335D',
        'title' => ' - 335d',
      ),
      29 => 
      array (
        'value' => '335I',
        'title' => ' - 335i',
      ),
      30 => 
      array (
        'value' => '335IS',
        'title' => ' - 335is',
      ),
      31 => 
      array (
        'value' => '335XI',
        'title' => ' - 335xi',
      ),
      32 => 
      array (
        'value' => 'ACTIVE3',
        'title' => ' - ActiveHybrid 3',
      ),
      33 => 
      array (
        'value' => 'BMW325',
        'title' => ' - 325',
      ),
      34 => 
      array (
        'value' => '5_SERIES',
        'title' => '5 Series (19)',
      ),
      35 => 
      array (
        'value' => '524TD',
        'title' => ' - 524td',
      ),
      36 => 
      array (
        'value' => '525I',
        'title' => ' - 525i',
      ),
      37 => 
      array (
        'value' => '525XI',
        'title' => ' - 525xi',
      ),
      38 => 
      array (
        'value' => '528E',
        'title' => ' - 528e',
      ),
      39 => 
      array (
        'value' => '528I',
        'title' => ' - 528i',
      ),
      40 => 
      array (
        'value' => '528IT',
        'title' => ' - 528iT',
      ),
      41 => 
      array (
        'value' => '528XI',
        'title' => ' - 528xi',
      ),
      42 => 
      array (
        'value' => '530I',
        'title' => ' - 530i',
      ),
      43 => 
      array (
        'value' => '530IT',
        'title' => ' - 530iT',
      ),
      44 => 
      array (
        'value' => '530XI',
        'title' => ' - 530xi',
      ),
      45 => 
      array (
        'value' => '533I',
        'title' => ' - 533i',
      ),
      46 => 
      array (
        'value' => '535I',
        'title' => ' - 535i',
      ),
      47 => 
      array (
        'value' => '535IGT',
        'title' => ' - 535i Gran Turismo',
      ),
      48 => 
      array (
        'value' => '535XI',
        'title' => ' - 535xi',
      ),
      49 => 
      array (
        'value' => '540I',
        'title' => ' - 540i',
      ),
      50 => 
      array (
        'value' => '545I',
        'title' => ' - 545i',
      ),
      51 => 
      array (
        'value' => '550I',
        'title' => ' - 550i',
      ),
      52 => 
      array (
        'value' => '550IGT',
        'title' => ' - 550i Gran Turismo',
      ),
      53 => 
      array (
        'value' => 'ACTIVE5',
        'title' => ' - ActiveHybrid 5',
      ),
      54 => 
      array (
        'value' => '6_SERIES',
        'title' => '6 Series (8)',
      ),
      55 => 
      array (
        'value' => '633CSI',
        'title' => ' - 633CSi',
      ),
      56 => 
      array (
        'value' => '635CSI',
        'title' => ' - 635CSi',
      ),
      57 => 
      array (
        'value' => '640I',
        'title' => ' - 640i',
      ),
      58 => 
      array (
        'value' => '640IGC',
        'title' => ' - 640i Gran Coupe',
      ),
      59 => 
      array (
        'value' => '645CI',
        'title' => ' - 645Ci',
      ),
      60 => 
      array (
        'value' => '650I',
        'title' => ' - 650i',
      ),
      61 => 
      array (
        'value' => '650IGC',
        'title' => ' - 650i Gran Coupe',
      ),
      62 => 
      array (
        'value' => 'L6',
        'title' => ' - L6',
      ),
      63 => 
      array (
        'value' => '7_SERIES',
        'title' => '7 Series (15)',
      ),
      64 => 
      array (
        'value' => '733I',
        'title' => ' - 733i',
      ),
      65 => 
      array (
        'value' => '735I',
        'title' => ' - 735i',
      ),
      66 => 
      array (
        'value' => '735IL',
        'title' => ' - 735iL',
      ),
      67 => 
      array (
        'value' => '740I',
        'title' => ' - 740i',
      ),
      68 => 
      array (
        'value' => '740IL',
        'title' => ' - 740iL',
      ),
      69 => 
      array (
        'value' => '740LI',
        'title' => ' - 740Li',
      ),
      70 => 
      array (
        'value' => '745I',
        'title' => ' - 745i',
      ),
      71 => 
      array (
        'value' => '745LI',
        'title' => ' - 745Li',
      ),
      72 => 
      array (
        'value' => '750I',
        'title' => ' - 750i',
      ),
      73 => 
      array (
        'value' => '750IL',
        'title' => ' - 750iL',
      ),
      74 => 
      array (
        'value' => '750LI',
        'title' => ' - 750Li',
      ),
      75 => 
      array (
        'value' => '760I',
        'title' => ' - 760i',
      ),
      76 => 
      array (
        'value' => '760LI',
        'title' => ' - 760Li',
      ),
      77 => 
      array (
        'value' => 'ACTIVE7',
        'title' => ' - ActiveHybrid 7',
      ),
      78 => 
      array (
        'value' => 'ALPINAB7',
        'title' => ' - Alpina B7',
      ),
      79 => 
      array (
        'value' => '8_SERIES',
        'title' => '8 Series (4)',
      ),
      80 => 
      array (
        'value' => '840CI',
        'title' => ' - 840Ci',
      ),
      81 => 
      array (
        'value' => '850CI',
        'title' => ' - 850Ci',
      ),
      82 => 
      array (
        'value' => '850CSI',
        'title' => ' - 850CSi',
      ),
      83 => 
      array (
        'value' => '850I',
        'title' => ' - 850i',
      ),
      84 => 
      array (
        'value' => 'L_SERIES',
        'title' => 'L Series (1)',
      ),
      85 => 
      array (
        'value' => 'L7',
        'title' => ' - L7',
      ),
      86 => 
      array (
        'value' => 'M_SERIES',
        'title' => 'M Series (8)',
      ),
      87 => 
      array (
        'value' => '1SERIESM',
        'title' => ' - 1 Series M',
      ),
      88 => 
      array (
        'value' => 'BMWMCOUPE',
        'title' => ' - M Coupe',
      ),
      89 => 
      array (
        'value' => 'BMWROAD',
        'title' => ' - M Roadster',
      ),
      90 => 
      array (
        'value' => 'M3',
        'title' => ' - M3',
      ),
      91 => 
      array (
        'value' => 'M5',
        'title' => ' - M5',
      ),
      92 => 
      array (
        'value' => 'M6',
        'title' => ' - M6',
      ),
      93 => 
      array (
        'value' => 'X5M',
        'title' => ' - X5 M',
      ),
      94 => 
      array (
        'value' => 'X6M',
        'title' => ' - X6 M',
      ),
      95 => 
      array (
        'value' => 'X_SERIES',
        'title' => 'X Series (5)',
      ),
      96 => 
      array (
        'value' => 'ACTIVEX6',
        'title' => ' - ActiveHybrid X6',
      ),
      97 => 
      array (
        'value' => 'X1',
        'title' => ' - X1',
      ),
      98 => 
      array (
        'value' => 'X3',
        'title' => ' - X3',
      ),
      99 => 
      array (
        'value' => 'X5',
        'title' => ' - X5',
      ),
      100 => 
      array (
        'value' => 'X6',
        'title' => ' - X6',
      ),
      101 => 
      array (
        'value' => 'Z_SERIES',
        'title' => 'Z Series (3)',
      ),
      102 => 
      array (
        'value' => 'Z3',
        'title' => ' - Z3',
      ),
      103 => 
      array (
        'value' => 'Z4',
        'title' => ' - Z4',
      ),
      104 => 
      array (
        'value' => 'Z8',
        'title' => ' - Z8',
      ),
      105 => 
      array (
        'value' => 'BMWOTH',
        'title' => 'Other BMW Models',
      ),
    ),
  ),
  8 => 
  array (
    'value' => 'BUICK',
    'title' => 'Buick',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'CENT',
        'title' => 'Century',
      ),
      1 => 
      array (
        'value' => 'ELEC',
        'title' => 'Electra',
      ),
      2 => 
      array (
        'value' => 'ENCLAVE',
        'title' => 'Enclave',
      ),
      3 => 
      array (
        'value' => 'BUIENC',
        'title' => 'Encore',
      ),
      4 => 
      array (
        'value' => 'LACROSSE',
        'title' => 'LaCrosse',
      ),
      5 => 
      array (
        'value' => 'LESA',
        'title' => 'Le Sabre',
      ),
      6 => 
      array (
        'value' => 'LUCERNE',
        'title' => 'Lucerne',
      ),
      7 => 
      array (
        'value' => 'PARK',
        'title' => 'Park Avenue',
      ),
      8 => 
      array (
        'value' => 'RAINIER',
        'title' => 'Rainier',
      ),
      9 => 
      array (
        'value' => 'REATTA',
        'title' => 'Reatta',
      ),
      10 => 
      array (
        'value' => 'REG',
        'title' => 'Regal',
      ),
      11 => 
      array (
        'value' => 'RENDEZVOUS',
        'title' => 'Rendezvous',
      ),
      12 => 
      array (
        'value' => 'RIV',
        'title' => 'Riviera',
      ),
      13 => 
      array (
        'value' => 'BUICKROAD',
        'title' => 'Roadmaster',
      ),
      14 => 
      array (
        'value' => 'SKYH',
        'title' => 'Skyhawk',
      ),
      15 => 
      array (
        'value' => 'SKYL',
        'title' => 'Skylark',
      ),
      16 => 
      array (
        'value' => 'SOMER',
        'title' => 'Somerset',
      ),
      17 => 
      array (
        'value' => 'TERRAZA',
        'title' => 'Terraza',
      ),
      18 => 
      array (
        'value' => 'BUVERANO',
        'title' => 'Verano',
      ),
      19 => 
      array (
        'value' => 'BUOTH',
        'title' => 'Other Buick Models',
      ),
    ),
  ),
  9 => 
  array (
    'value' => 'CAD',
    'title' => 'Cadillac',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ALLANT',
        'title' => 'Allante',
      ),
      1 => 
      array (
        'value' => 'ATS',
        'title' => 'ATS',
      ),
      2 => 
      array (
        'value' => 'BROUGH',
        'title' => 'Brougham',
      ),
      3 => 
      array (
        'value' => 'CATERA',
        'title' => 'Catera',
      ),
      4 => 
      array (
        'value' => 'CIMA',
        'title' => 'Cimarron',
      ),
      5 => 
      array (
        'value' => 'CTS',
        'title' => 'CTS',
      ),
      6 => 
      array (
        'value' => 'DEV',
        'title' => 'De Ville',
      ),
      7 => 
      array (
        'value' => 'DTS',
        'title' => 'DTS',
      ),
      8 => 
      array (
        'value' => 'ELDO',
        'title' => 'Eldorado',
      ),
      9 => 
      array (
        'value' => 'ESCALA',
        'title' => 'Escalade',
      ),
      10 => 
      array (
        'value' => 'ESCALAESV',
        'title' => 'Escalade ESV',
      ),
      11 => 
      array (
        'value' => 'EXT',
        'title' => 'Escalade EXT',
      ),
      12 => 
      array (
        'value' => 'FLEE',
        'title' => 'Fleetwood',
      ),
      13 => 
      array (
        'value' => 'SEV',
        'title' => 'Seville',
      ),
      14 => 
      array (
        'value' => 'SRX',
        'title' => 'SRX',
      ),
      15 => 
      array (
        'value' => 'STS',
        'title' => 'STS',
      ),
      16 => 
      array (
        'value' => 'XLR',
        'title' => 'XLR',
      ),
      17 => 
      array (
        'value' => 'XTS',
        'title' => 'XTS',
      ),
      18 => 
      array (
        'value' => 'CADOTH',
        'title' => 'Other Cadillac Models',
      ),
    ),
  ),
  10 => 
  array (
    'value' => 'CHEV',
    'title' => 'Chevrolet',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ASTRO',
        'title' => 'Astro',
      ),
      1 => 
      array (
        'value' => 'AVALNCH',
        'title' => 'Avalanche',
      ),
      2 => 
      array (
        'value' => 'AVEO',
        'title' => 'Aveo',
      ),
      3 => 
      array (
        'value' => 'AVEO5',
        'title' => 'Aveo5',
      ),
      4 => 
      array (
        'value' => 'BERETT',
        'title' => 'Beretta',
      ),
      5 => 
      array (
        'value' => 'BLAZER',
        'title' => 'Blazer',
      ),
      6 => 
      array (
        'value' => 'CAM',
        'title' => 'Camaro',
      ),
      7 => 
      array (
        'value' => 'CAP',
        'title' => 'Caprice',
      ),
      8 => 
      array (
        'value' => 'CHECAPS',
        'title' => 'Captiva Sport',
      ),
      9 => 
      array (
        'value' => 'CAV',
        'title' => 'Cavalier',
      ),
      10 => 
      array (
        'value' => 'CELE',
        'title' => 'Celebrity',
      ),
      11 => 
      array (
        'value' => 'CHEVETTE',
        'title' => 'Chevette',
      ),
      12 => 
      array (
        'value' => 'CITATION',
        'title' => 'Citation',
      ),
      13 => 
      array (
        'value' => 'COBALT',
        'title' => 'Cobalt',
      ),
      14 => 
      array (
        'value' => 'COLORADO',
        'title' => 'Colorado',
      ),
      15 => 
      array (
        'value' => 'CORSI',
        'title' => 'Corsica',
      ),
      16 => 
      array (
        'value' => 'CORV',
        'title' => 'Corvette',
      ),
      17 => 
      array (
        'value' => 'CRUZE',
        'title' => 'Cruze',
      ),
      18 => 
      array (
        'value' => 'ELCAM',
        'title' => 'El Camino',
      ),
      19 => 
      array (
        'value' => 'EQUINOX',
        'title' => 'Equinox',
      ),
      20 => 
      array (
        'value' => 'G15EXP',
        'title' => 'Express Van',
      ),
      21 => 
      array (
        'value' => 'G10',
        'title' => 'G Van',
      ),
      22 => 
      array (
        'value' => 'HHR',
        'title' => 'HHR',
      ),
      23 => 
      array (
        'value' => 'CHEVIMP',
        'title' => 'Impala',
      ),
      24 => 
      array (
        'value' => 'KODC4500',
        'title' => 'Kodiak C4500',
      ),
      25 => 
      array (
        'value' => 'LUMINA',
        'title' => 'Lumina',
      ),
      26 => 
      array (
        'value' => 'LAPV',
        'title' => 'Lumina APV',
      ),
      27 => 
      array (
        'value' => 'LUV',
        'title' => 'LUV',
      ),
      28 => 
      array (
        'value' => 'MALI',
        'title' => 'Malibu',
      ),
      29 => 
      array (
        'value' => 'CHVMETR',
        'title' => 'Metro',
      ),
      30 => 
      array (
        'value' => 'CHEVMONT',
        'title' => 'Monte Carlo',
      ),
      31 => 
      array (
        'value' => 'NOVA',
        'title' => 'Nova',
      ),
      32 => 
      array (
        'value' => 'CHEVPRIZM',
        'title' => 'Prizm',
      ),
      33 => 
      array (
        'value' => 'CHVST',
        'title' => 'S10 Blazer',
      ),
      34 => 
      array (
        'value' => 'S10PICKUP',
        'title' => 'S10 Pickup',
      ),
      35 => 
      array (
        'value' => 'CHEV150',
        'title' => 'Silverado and other C/K1500',
      ),
      36 => 
      array (
        'value' => 'CHEVC25',
        'title' => 'Silverado and other C/K2500',
      ),
      37 => 
      array (
        'value' => 'CH3500PU',
        'title' => 'Silverado and other C/K3500',
      ),
      38 => 
      array (
        'value' => 'SONIC',
        'title' => 'Sonic',
      ),
      39 => 
      array (
        'value' => 'SPARK',
        'title' => 'Spark',
      ),
      40 => 
      array (
        'value' => 'CHEVSPEC',
        'title' => 'Spectrum',
      ),
      41 => 
      array (
        'value' => 'CHSPRINT',
        'title' => 'Sprint',
      ),
      42 => 
      array (
        'value' => 'SSR',
        'title' => 'SSR',
      ),
      43 => 
      array (
        'value' => 'CHEVSUB',
        'title' => 'Suburban',
      ),
      44 => 
      array (
        'value' => 'TAHOE',
        'title' => 'Tahoe',
      ),
      45 => 
      array (
        'value' => 'TRACKE',
        'title' => 'Tracker',
      ),
      46 => 
      array (
        'value' => 'TRAILBLZ',
        'title' => 'TrailBlazer',
      ),
      47 => 
      array (
        'value' => 'TRAILBZEXT',
        'title' => 'TrailBlazer EXT',
      ),
      48 => 
      array (
        'value' => 'TRAVERSE',
        'title' => 'Traverse',
      ),
      49 => 
      array (
        'value' => 'UPLANDER',
        'title' => 'Uplander',
      ),
      50 => 
      array (
        'value' => 'VENTUR',
        'title' => 'Venture',
      ),
      51 => 
      array (
        'value' => 'VOLT',
        'title' => 'Volt',
      ),
      52 => 
      array (
        'value' => 'CHEOTH',
        'title' => 'Other Chevrolet Models',
      ),
    ),
  ),
  11 => 
  array (
    'value' => 'CHRY',
    'title' => 'Chrysler',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'CHRYS200',
        'title' => '200',
      ),
      1 => 
      array (
        'value' => '300',
        'title' => '300',
      ),
      2 => 
      array (
        'value' => 'CHRY300',
        'title' => '300M',
      ),
      3 => 
      array (
        'value' => 'ASPEN',
        'title' => 'Aspen',
      ),
      4 => 
      array (
        'value' => 'CARAVAN',
        'title' => 'Caravan',
      ),
      5 => 
      array (
        'value' => 'CIRRUS',
        'title' => 'Cirrus',
      ),
      6 => 
      array (
        'value' => 'CONC',
        'title' => 'Concorde',
      ),
      7 => 
      array (
        'value' => 'CHRYCONQ',
        'title' => 'Conquest',
      ),
      8 => 
      array (
        'value' => 'CORDOBA',
        'title' => 'Cordoba',
      ),
      9 => 
      array (
        'value' => 'CROSSFIRE',
        'title' => 'Crossfire',
      ),
      10 => 
      array (
        'value' => 'ECLASS',
        'title' => 'E Class',
      ),
      11 => 
      array (
        'value' => 'FIFTH',
        'title' => 'Fifth Avenue',
      ),
      12 => 
      array (
        'value' => 'CHRYGRANDV',
        'title' => 'Grand Voyager',
      ),
      13 => 
      array (
        'value' => 'IMPE',
        'title' => 'Imperial',
      ),
      14 => 
      array (
        'value' => 'INTREPID',
        'title' => 'Intrepid',
      ),
      15 => 
      array (
        'value' => 'CHRYLAS',
        'title' => 'Laser',
      ),
      16 => 
      array (
        'value' => 'LEBA',
        'title' => 'LeBaron',
      ),
      17 => 
      array (
        'value' => 'LHS',
        'title' => 'LHS',
      ),
      18 => 
      array (
        'value' => 'CHRYNEON',
        'title' => 'Neon',
      ),
      19 => 
      array (
        'value' => 'NY',
        'title' => 'New Yorker',
      ),
      20 => 
      array (
        'value' => 'NEWPORT',
        'title' => 'Newport',
      ),
      21 => 
      array (
        'value' => 'PACIFICA',
        'title' => 'Pacifica',
      ),
      22 => 
      array (
        'value' => 'CHPROWLE',
        'title' => 'Prowler',
      ),
      23 => 
      array (
        'value' => 'PTCRUIS',
        'title' => 'PT Cruiser',
      ),
      24 => 
      array (
        'value' => 'CHRYSEB',
        'title' => 'Sebring',
      ),
      25 => 
      array (
        'value' => 'CHRYTC',
        'title' => 'TC by Maserati',
      ),
      26 => 
      array (
        'value' => 'TANDC',
        'title' => 'Town & Country',
      ),
      27 => 
      array (
        'value' => 'VOYAGER',
        'title' => 'Voyager',
      ),
      28 => 
      array (
        'value' => 'CHOTH',
        'title' => 'Other Chrysler Models',
      ),
    ),
  ),
  12 => 
  array (
    'value' => 'DAEW',
    'title' => 'Daewoo',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'LANOS',
        'title' => 'Lanos',
      ),
      1 => 
      array (
        'value' => 'LEGANZA',
        'title' => 'Leganza',
      ),
      2 => 
      array (
        'value' => 'NUBIRA',
        'title' => 'Nubira',
      ),
      3 => 
      array (
        'value' => 'DAEOTH',
        'title' => 'Other Daewoo Models',
      ),
    ),
  ),
  13 => 
  array (
    'value' => 'DAIHAT',
    'title' => 'Daihatsu',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'CHAR',
        'title' => 'Charade',
      ),
      1 => 
      array (
        'value' => 'ROCKY',
        'title' => 'Rocky',
      ),
      2 => 
      array (
        'value' => 'DAIHOTH',
        'title' => 'Other Daihatsu Models',
      ),
    ),
  ),
  14 => 
  array (
    'value' => 'DATSUN',
    'title' => 'Datsun',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'DAT200SX',
        'title' => '200SX',
      ),
      1 => 
      array (
        'value' => 'DAT210',
        'title' => '210',
      ),
      2 => 
      array (
        'value' => '280Z',
        'title' => '280ZX',
      ),
      3 => 
      array (
        'value' => '300ZX',
        'title' => '300ZX',
      ),
      4 => 
      array (
        'value' => '310',
        'title' => '310',
      ),
      5 => 
      array (
        'value' => '510',
        'title' => '510',
      ),
      6 => 
      array (
        'value' => '720',
        'title' => '720',
      ),
      7 => 
      array (
        'value' => '810',
        'title' => '810',
      ),
      8 => 
      array (
        'value' => 'DATMAX',
        'title' => 'Maxima',
      ),
      9 => 
      array (
        'value' => 'DATPU',
        'title' => 'Pickup',
      ),
      10 => 
      array (
        'value' => 'PUL',
        'title' => 'Pulsar',
      ),
      11 => 
      array (
        'value' => 'DATSENT',
        'title' => 'Sentra',
      ),
      12 => 
      array (
        'value' => 'STAN',
        'title' => 'Stanza',
      ),
      13 => 
      array (
        'value' => 'DATOTH',
        'title' => 'Other Datsun Models',
      ),
    ),
  ),
  15 => 
  array (
    'value' => 'DELOREAN',
    'title' => 'DeLorean',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'DMC12',
        'title' => 'DMC-12',
      ),
    ),
  ),
  16 => 
  array (
    'value' => 'DODGE',
    'title' => 'Dodge',
    'models' => 
    array (
      0 => 
      array (
        'value' => '400',
        'title' => '400',
      ),
      1 => 
      array (
        'value' => 'DOD600',
        'title' => '600',
      ),
      2 => 
      array (
        'value' => 'ARI',
        'title' => 'Aries',
      ),
      3 => 
      array (
        'value' => 'AVENGR',
        'title' => 'Avenger',
      ),
      4 => 
      array (
        'value' => 'CALIBER',
        'title' => 'Caliber',
      ),
      5 => 
      array (
        'value' => 'DODCARA',
        'title' => 'Caravan',
      ),
      6 => 
      array (
        'value' => 'CHALLENGER',
        'title' => 'Challenger',
      ),
      7 => 
      array (
        'value' => 'DODCHAR',
        'title' => 'Charger',
      ),
      8 => 
      array (
        'value' => 'DODCOLT',
        'title' => 'Colt',
      ),
      9 => 
      array (
        'value' => 'DODCONQ',
        'title' => 'Conquest',
      ),
      10 => 
      array (
        'value' => 'DODDW',
        'title' => 'D/W Truck',
      ),
      11 => 
      array (
        'value' => 'DAKOTA',
        'title' => 'Dakota',
      ),
      12 => 
      array (
        'value' => 'DODDART',
        'title' => 'Dart',
      ),
      13 => 
      array (
        'value' => 'DAY',
        'title' => 'Daytona',
      ),
      14 => 
      array (
        'value' => 'DIPLOMA',
        'title' => 'Diplomat',
      ),
      15 => 
      array (
        'value' => 'DURANG',
        'title' => 'Durango',
      ),
      16 => 
      array (
        'value' => 'DODDYNA',
        'title' => 'Dynasty',
      ),
      17 => 
      array (
        'value' => 'GRANDCARAV',
        'title' => 'Grand Caravan',
      ),
      18 => 
      array (
        'value' => 'INTRE',
        'title' => 'Intrepid',
      ),
      19 => 
      array (
        'value' => 'JOURNEY',
        'title' => 'Journey',
      ),
      20 => 
      array (
        'value' => 'LANCERDODG',
        'title' => 'Lancer',
      ),
      21 => 
      array (
        'value' => 'MAGNUM',
        'title' => 'Magnum',
      ),
      22 => 
      array (
        'value' => 'MIRADA',
        'title' => 'Mirada',
      ),
      23 => 
      array (
        'value' => 'MONACO',
        'title' => 'Monaco',
      ),
      24 => 
      array (
        'value' => 'DODNEON',
        'title' => 'Neon',
      ),
      25 => 
      array (
        'value' => 'NITRO',
        'title' => 'Nitro',
      ),
      26 => 
      array (
        'value' => 'OMNI',
        'title' => 'Omni',
      ),
      27 => 
      array (
        'value' => 'RAIDER',
        'title' => 'Raider',
      ),
      28 => 
      array (
        'value' => 'RAM1504WD',
        'title' => 'Ram 1500 Truck',
      ),
      29 => 
      array (
        'value' => 'RAM25002WD',
        'title' => 'Ram 2500 Truck',
      ),
      30 => 
      array (
        'value' => 'RAM3502WD',
        'title' => 'Ram 3500 Truck',
      ),
      31 => 
      array (
        'value' => 'RAM4500',
        'title' => 'Ram 4500 Truck',
      ),
      32 => 
      array (
        'value' => 'DODD50',
        'title' => 'Ram 50 Truck',
      ),
      33 => 
      array (
        'value' => 'CV',
        'title' => 'RAM C/V',
      ),
      34 => 
      array (
        'value' => 'RAMSRT10',
        'title' => 'Ram SRT-10',
      ),
      35 => 
      array (
        'value' => 'RAMVANV8',
        'title' => 'Ram Van',
      ),
      36 => 
      array (
        'value' => 'RAMWAGON',
        'title' => 'Ram Wagon',
      ),
      37 => 
      array (
        'value' => 'RAMCGR',
        'title' => 'Ramcharger',
      ),
      38 => 
      array (
        'value' => 'RAMPAGE',
        'title' => 'Rampage',
      ),
      39 => 
      array (
        'value' => 'DODSHAD',
        'title' => 'Shadow',
      ),
      40 => 
      array (
        'value' => 'DODSPIR',
        'title' => 'Spirit',
      ),
      41 => 
      array (
        'value' => 'SPRINTER',
        'title' => 'Sprinter',
      ),
      42 => 
      array (
        'value' => 'SRT4',
        'title' => 'SRT-4',
      ),
      43 => 
      array (
        'value' => 'STREGIS',
        'title' => 'St. Regis',
      ),
      44 => 
      array (
        'value' => 'STEAL',
        'title' => 'Stealth',
      ),
      45 => 
      array (
        'value' => 'STRATU',
        'title' => 'Stratus',
      ),
      46 => 
      array (
        'value' => 'VIPER',
        'title' => 'Viper',
      ),
      47 => 
      array (
        'value' => 'DOOTH',
        'title' => 'Other Dodge Models',
      ),
    ),
  ),
  17 => 
  array (
    'value' => 'EAGLE',
    'title' => 'Eagle',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'EAGLEMED',
        'title' => 'Medallion',
      ),
      1 => 
      array (
        'value' => 'EAGLEPREM',
        'title' => 'Premier',
      ),
      2 => 
      array (
        'value' => 'SUMMIT',
        'title' => 'Summit',
      ),
      3 => 
      array (
        'value' => 'TALON',
        'title' => 'Talon',
      ),
      4 => 
      array (
        'value' => 'VISION',
        'title' => 'Vision',
      ),
      5 => 
      array (
        'value' => 'EAGOTH',
        'title' => 'Other Eagle Models',
      ),
    ),
  ),
  18 => 
  array (
    'value' => 'FER',
    'title' => 'Ferrari',
    'models' => 
    array (
      0 => 
      array (
        'value' => '308GTB',
        'title' => '308 GTB Quattrovalvole',
      ),
      1 => 
      array (
        'value' => '308TBI',
        'title' => '308 GTBI',
      ),
      2 => 
      array (
        'value' => '308GTS',
        'title' => '308 GTS Quattrovalvole',
      ),
      3 => 
      array (
        'value' => '308TSI',
        'title' => '308 GTSI',
      ),
      4 => 
      array (
        'value' => '328GTB',
        'title' => '328 GTB',
      ),
      5 => 
      array (
        'value' => '328GTS',
        'title' => '328 GTS',
      ),
      6 => 
      array (
        'value' => '348GTB',
        'title' => '348 GTB',
      ),
      7 => 
      array (
        'value' => '348GTS',
        'title' => '348 GTS',
      ),
      8 => 
      array (
        'value' => '348SPI',
        'title' => '348 Spider',
      ),
      9 => 
      array (
        'value' => '348TB',
        'title' => '348 TB',
      ),
      10 => 
      array (
        'value' => '348TS',
        'title' => '348 TS',
      ),
      11 => 
      array (
        'value' => '360',
        'title' => '360',
      ),
      12 => 
      array (
        'value' => '456GT',
        'title' => '456 GT',
      ),
      13 => 
      array (
        'value' => '456MGT',
        'title' => '456M GT',
      ),
      14 => 
      array (
        'value' => '458ITALIA',
        'title' => '458 Italia',
      ),
      15 => 
      array (
        'value' => '512BBI',
        'title' => '512 BBi',
      ),
      16 => 
      array (
        'value' => '512M',
        'title' => '512M',
      ),
      17 => 
      array (
        'value' => '512TR',
        'title' => '512TR',
      ),
      18 => 
      array (
        'value' => '550M',
        'title' => '550 Maranello',
      ),
      19 => 
      array (
        'value' => '575M',
        'title' => '575M Maranello',
      ),
      20 => 
      array (
        'value' => '599GTB',
        'title' => '599 GTB Fiorano',
      ),
      21 => 
      array (
        'value' => '599GTO',
        'title' => '599 GTO',
      ),
      22 => 
      array (
        'value' => '612SCAGLIE',
        'title' => '612 Scaglietti',
      ),
      23 => 
      array (
        'value' => 'FERCALIF',
        'title' => 'California',
      ),
      24 => 
      array (
        'value' => 'ENZO',
        'title' => 'Enzo',
      ),
      25 => 
      array (
        'value' => 'F355',
        'title' => 'F355',
      ),
      26 => 
      array (
        'value' => 'F40',
        'title' => 'F40',
      ),
      27 => 
      array (
        'value' => 'F430',
        'title' => 'F430',
      ),
      28 => 
      array (
        'value' => 'F50',
        'title' => 'F50',
      ),
      29 => 
      array (
        'value' => 'FERFF',
        'title' => 'FF',
      ),
      30 => 
      array (
        'value' => 'MOND',
        'title' => 'Mondial',
      ),
      31 => 
      array (
        'value' => 'TEST',
        'title' => 'Testarossa',
      ),
      32 => 
      array (
        'value' => 'UNAVAILFER',
        'title' => 'Other Ferrari Models',
      ),
    ),
  ),
  19 => 
  array (
    'value' => 'FIAT',
    'title' => 'FIAT',
    'models' => 
    array (
      0 => 
      array (
        'value' => '2000',
        'title' => '2000 Spider',
      ),
      1 => 
      array (
        'value' => 'FIAT500',
        'title' => '500',
      ),
      2 => 
      array (
        'value' => 'BERTON',
        'title' => 'Bertone X1/9',
      ),
      3 => 
      array (
        'value' => 'BRAVA',
        'title' => 'Brava',
      ),
      4 => 
      array (
        'value' => 'PININ',
        'title' => 'Pininfarina Spider',
      ),
      5 => 
      array (
        'value' => 'STRADA',
        'title' => 'Strada',
      ),
      6 => 
      array (
        'value' => 'FIATX19',
        'title' => 'X1/9',
      ),
      7 => 
      array (
        'value' => 'UNAVAILFIA',
        'title' => 'Other Fiat Models',
      ),
    ),
  ),
  20 => 
  array (
    'value' => 'FISK',
    'title' => 'Fisker',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'KARMA',
        'title' => 'Karma',
      ),
    ),
  ),
  21 => 
  array (
    'value' => 'FORD',
    'title' => 'Ford',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'AERO',
        'title' => 'Aerostar',
      ),
      1 => 
      array (
        'value' => 'ASPIRE',
        'title' => 'Aspire',
      ),
      2 => 
      array (
        'value' => 'BRON',
        'title' => 'Bronco',
      ),
      3 => 
      array (
        'value' => 'B2',
        'title' => 'Bronco II',
      ),
      4 => 
      array (
        'value' => 'FOCMAX',
        'title' => 'C-MAX',
      ),
      5 => 
      array (
        'value' => 'FORDCLUB',
        'title' => 'Club Wagon',
      ),
      6 => 
      array (
        'value' => 'CONTOUR',
        'title' => 'Contour',
      ),
      7 => 
      array (
        'value' => 'COURIER',
        'title' => 'Courier',
      ),
      8 => 
      array (
        'value' => 'CROWNVIC',
        'title' => 'Crown Victoria',
      ),
      9 => 
      array (
        'value' => 'E150ECON',
        'title' => 'E-150 and Econoline 150',
      ),
      10 => 
      array (
        'value' => 'E250ECON',
        'title' => 'E-250 and Econoline 250',
      ),
      11 => 
      array (
        'value' => 'E350ECON',
        'title' => 'E-350 and Econoline 350',
      ),
      12 => 
      array (
        'value' => 'EDGE',
        'title' => 'Edge',
      ),
      13 => 
      array (
        'value' => 'ESCAPE',
        'title' => 'Escape',
      ),
      14 => 
      array (
        'value' => 'ESCO',
        'title' => 'Escort',
      ),
      15 => 
      array (
        'value' => 'EXCURSION',
        'title' => 'Excursion',
      ),
      16 => 
      array (
        'value' => 'EXP',
        'title' => 'EXP',
      ),
      17 => 
      array (
        'value' => 'EXPEDI',
        'title' => 'Expedition',
      ),
      18 => 
      array (
        'value' => 'EXPEDIEL',
        'title' => 'Expedition EL',
      ),
      19 => 
      array (
        'value' => 'EXPLOR',
        'title' => 'Explorer',
      ),
      20 => 
      array (
        'value' => 'SPORTTRAC',
        'title' => 'Explorer Sport Trac',
      ),
      21 => 
      array (
        'value' => 'F100',
        'title' => 'F100',
      ),
      22 => 
      array (
        'value' => 'F150PICKUP',
        'title' => 'F150',
      ),
      23 => 
      array (
        'value' => 'F250',
        'title' => 'F250',
      ),
      24 => 
      array (
        'value' => 'F350',
        'title' => 'F350',
      ),
      25 => 
      array (
        'value' => 'F450',
        'title' => 'F450',
      ),
      26 => 
      array (
        'value' => 'FAIRM',
        'title' => 'Fairmont',
      ),
      27 => 
      array (
        'value' => 'FESTIV',
        'title' => 'Festiva',
      ),
      28 => 
      array (
        'value' => 'FIESTA',
        'title' => 'Fiesta',
      ),
      29 => 
      array (
        'value' => 'FIVEHUNDRE',
        'title' => 'Five Hundred',
      ),
      30 => 
      array (
        'value' => 'FLEX',
        'title' => 'Flex',
      ),
      31 => 
      array (
        'value' => 'FOCUS',
        'title' => 'Focus',
      ),
      32 => 
      array (
        'value' => 'FREESTAR',
        'title' => 'Freestar',
      ),
      33 => 
      array (
        'value' => 'FREESTYLE',
        'title' => 'Freestyle',
      ),
      34 => 
      array (
        'value' => 'FUSION',
        'title' => 'Fusion',
      ),
      35 => 
      array (
        'value' => 'GRANADA',
        'title' => 'Granada',
      ),
      36 => 
      array (
        'value' => 'GT',
        'title' => 'GT',
      ),
      37 => 
      array (
        'value' => 'LTD',
        'title' => 'LTD',
      ),
      38 => 
      array (
        'value' => 'MUST',
        'title' => 'Mustang',
      ),
      39 => 
      array (
        'value' => 'PROBE',
        'title' => 'Probe',
      ),
      40 => 
      array (
        'value' => 'RANGER',
        'title' => 'Ranger',
      ),
      41 => 
      array (
        'value' => 'TAURUS',
        'title' => 'Taurus',
      ),
      42 => 
      array (
        'value' => 'TAURUSX',
        'title' => 'Taurus X',
      ),
      43 => 
      array (
        'value' => 'TEMPO',
        'title' => 'Tempo',
      ),
      44 => 
      array (
        'value' => 'TBIRD',
        'title' => 'Thunderbird',
      ),
      45 => 
      array (
        'value' => 'TRANSCONN',
        'title' => 'Transit Connect',
      ),
      46 => 
      array (
        'value' => 'WINDST',
        'title' => 'Windstar',
      ),
      47 => 
      array (
        'value' => 'FORDZX2',
        'title' => 'ZX2 Escort',
      ),
      48 => 
      array (
        'value' => 'FOOTH',
        'title' => 'Other Ford Models',
      ),
    ),
  ),
  22 => 
  array (
    'value' => 'FREIGHT',
    'title' => 'Freightliner',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'FRESPRINT',
        'title' => 'Sprinter',
      ),
    ),
  ),
  23 => 
  array (
    'value' => 'GEO',
    'title' => 'Geo',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'GEOMETRO',
        'title' => 'Metro',
      ),
      1 => 
      array (
        'value' => 'GEOPRIZM',
        'title' => 'Prizm',
      ),
      2 => 
      array (
        'value' => 'SPECT',
        'title' => 'Spectrum',
      ),
      3 => 
      array (
        'value' => 'STORM',
        'title' => 'Storm',
      ),
      4 => 
      array (
        'value' => 'GEOTRACK',
        'title' => 'Tracker',
      ),
      5 => 
      array (
        'value' => 'GEOOTH',
        'title' => 'Other Geo Models',
      ),
    ),
  ),
  24 => 
  array (
    'value' => 'GMC',
    'title' => 'GMC',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ACADIA',
        'title' => 'Acadia',
      ),
      1 => 
      array (
        'value' => 'CABALLERO',
        'title' => 'Caballero',
      ),
      2 => 
      array (
        'value' => 'CANYON',
        'title' => 'Canyon',
      ),
      3 => 
      array (
        'value' => 'ENVOY',
        'title' => 'Envoy',
      ),
      4 => 
      array (
        'value' => 'ENVOYXL',
        'title' => 'Envoy XL',
      ),
      5 => 
      array (
        'value' => 'ENVOYXUV',
        'title' => 'Envoy XUV',
      ),
      6 => 
      array (
        'value' => 'JIM',
        'title' => 'Jimmy',
      ),
      7 => 
      array (
        'value' => 'RALLYWAG',
        'title' => 'Rally Wagon',
      ),
      8 => 
      array (
        'value' => 'GMCS15',
        'title' => 'S15 Jimmy',
      ),
      9 => 
      array (
        'value' => 'S15',
        'title' => 'S15 Pickup',
      ),
      10 => 
      array (
        'value' => 'SAFARIGMC',
        'title' => 'Safari',
      ),
      11 => 
      array (
        'value' => 'GMCSAVANA',
        'title' => 'Savana',
      ),
      12 => 
      array (
        'value' => '15SIPU4WD',
        'title' => 'Sierra C/K1500',
      ),
      13 => 
      array (
        'value' => 'GMCC25PU',
        'title' => 'Sierra C/K2500',
      ),
      14 => 
      array (
        'value' => 'GMC3500PU',
        'title' => 'Sierra C/K3500',
      ),
      15 => 
      array (
        'value' => 'SONOMA',
        'title' => 'Sonoma',
      ),
      16 => 
      array (
        'value' => 'SUB',
        'title' => 'Suburban',
      ),
      17 => 
      array (
        'value' => 'GMCSYCLON',
        'title' => 'Syclone',
      ),
      18 => 
      array (
        'value' => 'TERRAIN',
        'title' => 'Terrain',
      ),
      19 => 
      array (
        'value' => 'TOPC4500',
        'title' => 'TopKick C4500',
      ),
      20 => 
      array (
        'value' => 'TYPH',
        'title' => 'Typhoon',
      ),
      21 => 
      array (
        'value' => 'GMCVANDUR',
        'title' => 'Vandura',
      ),
      22 => 
      array (
        'value' => 'YUKON',
        'title' => 'Yukon',
      ),
      23 => 
      array (
        'value' => 'YUKONXL',
        'title' => 'Yukon XL',
      ),
      24 => 
      array (
        'value' => 'GMCOTH',
        'title' => 'Other GMC Models',
      ),
    ),
  ),
  25 => 
  array (
    'value' => 'HONDA',
    'title' => 'Honda',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ACCORD',
        'title' => 'Accord',
      ),
      1 => 
      array (
        'value' => 'CIVIC',
        'title' => 'Civic',
      ),
      2 => 
      array (
        'value' => 'CRV',
        'title' => 'CR-V',
      ),
      3 => 
      array (
        'value' => 'CRZ',
        'title' => 'CR-Z',
      ),
      4 => 
      array (
        'value' => 'CRX',
        'title' => 'CRX',
      ),
      5 => 
      array (
        'value' => 'CROSSTOUR_MODELS',
        'title' => 'Crosstour and Accord Crosstour Models (2)',
      ),
      6 => 
      array (
        'value' => 'CROSSTOUR',
        'title' => ' - Accord Crosstour',
      ),
      7 => 
      array (
        'value' => 'HONCROSS',
        'title' => ' - Crosstour',
      ),
      8 => 
      array (
        'value' => 'HONDELSOL',
        'title' => 'Del Sol',
      ),
      9 => 
      array (
        'value' => 'ELEMENT',
        'title' => 'Element',
      ),
      10 => 
      array (
        'value' => 'FIT',
        'title' => 'Fit',
      ),
      11 => 
      array (
        'value' => 'INSIGHT',
        'title' => 'Insight',
      ),
      12 => 
      array (
        'value' => 'ODYSSEY',
        'title' => 'Odyssey',
      ),
      13 => 
      array (
        'value' => 'PASSPO',
        'title' => 'Passport',
      ),
      14 => 
      array (
        'value' => 'PILOT',
        'title' => 'Pilot',
      ),
      15 => 
      array (
        'value' => 'PRE',
        'title' => 'Prelude',
      ),
      16 => 
      array (
        'value' => 'RIDGELINE',
        'title' => 'Ridgeline',
      ),
      17 => 
      array (
        'value' => 'S2000',
        'title' => 'S2000',
      ),
      18 => 
      array (
        'value' => 'HONOTH',
        'title' => 'Other Honda Models',
      ),
    ),
  ),
  26 => 
  array (
    'value' => 'AMGEN',
    'title' => 'HUMMER',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'HUMMER',
        'title' => 'H1',
      ),
      1 => 
      array (
        'value' => 'H2',
        'title' => 'H2',
      ),
      2 => 
      array (
        'value' => 'H3',
        'title' => 'H3',
      ),
      3 => 
      array (
        'value' => 'H3T',
        'title' => 'H3T',
      ),
      4 => 
      array (
        'value' => 'AMGOTH',
        'title' => 'Other Hummer Models',
      ),
    ),
  ),
  27 => 
  array (
    'value' => 'HYUND',
    'title' => 'Hyundai',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ACCENT',
        'title' => 'Accent',
      ),
      1 => 
      array (
        'value' => 'AZERA',
        'title' => 'Azera',
      ),
      2 => 
      array (
        'value' => 'ELANTR',
        'title' => 'Elantra',
      ),
      3 => 
      array (
        'value' => 'HYUELANCPE',
        'title' => 'Elantra Coupe',
      ),
      4 => 
      array (
        'value' => 'ELANTOUR',
        'title' => 'Elantra Touring',
      ),
      5 => 
      array (
        'value' => 'ENTOURAGE',
        'title' => 'Entourage',
      ),
      6 => 
      array (
        'value' => 'EQUUS',
        'title' => 'Equus',
      ),
      7 => 
      array (
        'value' => 'HYUEXCEL',
        'title' => 'Excel',
      ),
      8 => 
      array (
        'value' => 'GENESIS',
        'title' => 'Genesis',
      ),
      9 => 
      array (
        'value' => 'GENESISCPE',
        'title' => 'Genesis Coupe',
      ),
      10 => 
      array (
        'value' => 'SANTAFE',
        'title' => 'Santa Fe',
      ),
      11 => 
      array (
        'value' => 'SCOUPE',
        'title' => 'Scoupe',
      ),
      12 => 
      array (
        'value' => 'SONATA',
        'title' => 'Sonata',
      ),
      13 => 
      array (
        'value' => 'TIBURO',
        'title' => 'Tiburon',
      ),
      14 => 
      array (
        'value' => 'TUCSON',
        'title' => 'Tucson',
      ),
      15 => 
      array (
        'value' => 'VELOSTER',
        'title' => 'Veloster',
      ),
      16 => 
      array (
        'value' => 'VERACRUZ',
        'title' => 'Veracruz',
      ),
      17 => 
      array (
        'value' => 'XG300',
        'title' => 'XG300',
      ),
      18 => 
      array (
        'value' => 'XG350',
        'title' => 'XG350',
      ),
      19 => 
      array (
        'value' => 'HYUOTH',
        'title' => 'Other Hyundai Models',
      ),
    ),
  ),
  28 => 
  array (
    'value' => 'INFIN',
    'title' => 'Infiniti',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'EX_MODELS',
        'title' => 'EX Models (2)',
      ),
      1 => 
      array (
        'value' => 'EX35',
        'title' => ' - EX35',
      ),
      2 => 
      array (
        'value' => 'EX37',
        'title' => ' - EX37',
      ),
      3 => 
      array (
        'value' => 'FX_MODELS',
        'title' => 'FX Models (4)',
      ),
      4 => 
      array (
        'value' => 'FX35',
        'title' => ' - FX35',
      ),
      5 => 
      array (
        'value' => 'FX37',
        'title' => ' - FX37',
      ),
      6 => 
      array (
        'value' => 'FX45',
        'title' => ' - FX45',
      ),
      7 => 
      array (
        'value' => 'FX50',
        'title' => ' - FX50',
      ),
      8 => 
      array (
        'value' => 'G_MODELS',
        'title' => 'G Models (4)',
      ),
      9 => 
      array (
        'value' => 'G20',
        'title' => ' - G20',
      ),
      10 => 
      array (
        'value' => 'G25',
        'title' => ' - G25',
      ),
      11 => 
      array (
        'value' => 'G35',
        'title' => ' - G35',
      ),
      12 => 
      array (
        'value' => 'G37',
        'title' => ' - G37',
      ),
      13 => 
      array (
        'value' => 'I_MODELS',
        'title' => 'I Models (2)',
      ),
      14 => 
      array (
        'value' => 'I30',
        'title' => ' - I30',
      ),
      15 => 
      array (
        'value' => 'I35',
        'title' => ' - I35',
      ),
      16 => 
      array (
        'value' => 'J_MODELS',
        'title' => 'J Models (1)',
      ),
      17 => 
      array (
        'value' => 'J30',
        'title' => ' - J30',
      ),
      18 => 
      array (
        'value' => 'JX_MODELS',
        'title' => 'JX Models (1)',
      ),
      19 => 
      array (
        'value' => 'JX35',
        'title' => ' - JX35',
      ),
      20 => 
      array (
        'value' => 'M_MODELS',
        'title' => 'M Models (6)',
      ),
      21 => 
      array (
        'value' => 'M30',
        'title' => ' - M30',
      ),
      22 => 
      array (
        'value' => 'M35',
        'title' => ' - M35',
      ),
      23 => 
      array (
        'value' => 'M35HYBRID',
        'title' => ' - M35h',
      ),
      24 => 
      array (
        'value' => 'M37',
        'title' => ' - M37',
      ),
      25 => 
      array (
        'value' => 'M45',
        'title' => ' - M45',
      ),
      26 => 
      array (
        'value' => 'M56',
        'title' => ' - M56',
      ),
      27 => 
      array (
        'value' => 'Q_MODELS',
        'title' => 'Q Models (1)',
      ),
      28 => 
      array (
        'value' => 'Q45',
        'title' => ' - Q45',
      ),
      29 => 
      array (
        'value' => 'QX_MODELS',
        'title' => 'QX Models (2)',
      ),
      30 => 
      array (
        'value' => 'QX4',
        'title' => ' - QX4',
      ),
      31 => 
      array (
        'value' => 'QX56',
        'title' => ' - QX56',
      ),
      32 => 
      array (
        'value' => 'INFOTH',
        'title' => 'Other Infiniti Models',
      ),
    ),
  ),
  29 => 
  array (
    'value' => 'ISU',
    'title' => 'Isuzu',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'AMIGO',
        'title' => 'Amigo',
      ),
      1 => 
      array (
        'value' => 'ASCENDER',
        'title' => 'Ascender',
      ),
      2 => 
      array (
        'value' => 'AXIOM',
        'title' => 'Axiom',
      ),
      3 => 
      array (
        'value' => 'HOMBRE',
        'title' => 'Hombre',
      ),
      4 => 
      array (
        'value' => 'I280',
        'title' => 'i-280',
      ),
      5 => 
      array (
        'value' => 'I290',
        'title' => 'i-290',
      ),
      6 => 
      array (
        'value' => 'I350',
        'title' => 'i-350',
      ),
      7 => 
      array (
        'value' => 'I370',
        'title' => 'i-370',
      ),
      8 => 
      array (
        'value' => 'ISUMARK',
        'title' => 'I-Mark',
      ),
      9 => 
      array (
        'value' => 'ISUIMP',
        'title' => 'Impulse',
      ),
      10 => 
      array (
        'value' => 'OASIS',
        'title' => 'Oasis',
      ),
      11 => 
      array (
        'value' => 'ISUPU',
        'title' => 'Pickup',
      ),
      12 => 
      array (
        'value' => 'RODEO',
        'title' => 'Rodeo',
      ),
      13 => 
      array (
        'value' => 'STYLUS',
        'title' => 'Stylus',
      ),
      14 => 
      array (
        'value' => 'TROOP',
        'title' => 'Trooper',
      ),
      15 => 
      array (
        'value' => 'TRP2',
        'title' => 'Trooper II',
      ),
      16 => 
      array (
        'value' => 'VEHICROSS',
        'title' => 'VehiCROSS',
      ),
      17 => 
      array (
        'value' => 'ISUOTH',
        'title' => 'Other Isuzu Models',
      ),
    ),
  ),
  30 => 
  array (
    'value' => 'JAG',
    'title' => 'Jaguar',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'STYPE',
        'title' => 'S-Type',
      ),
      1 => 
      array (
        'value' => 'XTYPE',
        'title' => 'X-Type',
      ),
      2 => 
      array (
        'value' => 'XF',
        'title' => 'XF',
      ),
      3 => 
      array (
        'value' => 'XJ_SERIES',
        'title' => 'XJ Series (10)',
      ),
      4 => 
      array (
        'value' => 'JAGXJ12',
        'title' => ' - XJ12',
      ),
      5 => 
      array (
        'value' => 'JAGXJ6',
        'title' => ' - XJ6',
      ),
      6 => 
      array (
        'value' => 'JAGXJR',
        'title' => ' - XJR',
      ),
      7 => 
      array (
        'value' => 'JAGXJRS',
        'title' => ' - XJR-S',
      ),
      8 => 
      array (
        'value' => 'JAGXJS',
        'title' => ' - XJS',
      ),
      9 => 
      array (
        'value' => 'VANDEN',
        'title' => ' - XJ Vanden Plas',
      ),
      10 => 
      array (
        'value' => 'XJ',
        'title' => ' - XJ',
      ),
      11 => 
      array (
        'value' => 'XJ8',
        'title' => ' - XJ8',
      ),
      12 => 
      array (
        'value' => 'XJ8L',
        'title' => ' - XJ8 L',
      ),
      13 => 
      array (
        'value' => 'XJSPORT',
        'title' => ' - XJ Sport',
      ),
      14 => 
      array (
        'value' => 'XK_SERIES',
        'title' => 'XK Series (3)',
      ),
      15 => 
      array (
        'value' => 'JAGXK8',
        'title' => ' - XK8',
      ),
      16 => 
      array (
        'value' => 'XK',
        'title' => ' - XK',
      ),
      17 => 
      array (
        'value' => 'XKR',
        'title' => ' - XKR',
      ),
      18 => 
      array (
        'value' => 'JAGOTH',
        'title' => 'Other Jaguar Models',
      ),
    ),
  ),
  31 => 
  array (
    'value' => 'JEEP',
    'title' => 'Jeep',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'CHER',
        'title' => 'Cherokee',
      ),
      1 => 
      array (
        'value' => 'JEEPCJ',
        'title' => 'CJ',
      ),
      2 => 
      array (
        'value' => 'COMANC',
        'title' => 'Comanche',
      ),
      3 => 
      array (
        'value' => 'COMMANDER',
        'title' => 'Commander',
      ),
      4 => 
      array (
        'value' => 'COMPASS',
        'title' => 'Compass',
      ),
      5 => 
      array (
        'value' => 'JEEPGRAND',
        'title' => 'Grand Cherokee',
      ),
      6 => 
      array (
        'value' => 'GRWAG',
        'title' => 'Grand Wagoneer',
      ),
      7 => 
      array (
        'value' => 'LIBERTY',
        'title' => 'Liberty',
      ),
      8 => 
      array (
        'value' => 'PATRIOT',
        'title' => 'Patriot',
      ),
      9 => 
      array (
        'value' => 'JEEPPU',
        'title' => 'Pickup',
      ),
      10 => 
      array (
        'value' => 'SCRAMBLE',
        'title' => 'Scrambler',
      ),
      11 => 
      array (
        'value' => 'WAGONE',
        'title' => 'Wagoneer',
      ),
      12 => 
      array (
        'value' => 'WRANGLER',
        'title' => 'Wrangler',
      ),
      13 => 
      array (
        'value' => 'JEOTH',
        'title' => 'Other Jeep Models',
      ),
    ),
  ),
  32 => 
  array (
    'value' => 'KIA',
    'title' => 'Kia',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'AMANTI',
        'title' => 'Amanti',
      ),
      1 => 
      array (
        'value' => 'BORREGO',
        'title' => 'Borrego',
      ),
      2 => 
      array (
        'value' => 'FORTE',
        'title' => 'Forte',
      ),
      3 => 
      array (
        'value' => 'FORTEKOUP',
        'title' => 'Forte Koup',
      ),
      4 => 
      array (
        'value' => 'OPTIMA',
        'title' => 'Optima',
      ),
      5 => 
      array (
        'value' => 'RIO',
        'title' => 'Rio',
      ),
      6 => 
      array (
        'value' => 'RIO5',
        'title' => 'Rio5',
      ),
      7 => 
      array (
        'value' => 'RONDO',
        'title' => 'Rondo',
      ),
      8 => 
      array (
        'value' => 'SEDONA',
        'title' => 'Sedona',
      ),
      9 => 
      array (
        'value' => 'SEPHIA',
        'title' => 'Sephia',
      ),
      10 => 
      array (
        'value' => 'SORENTO',
        'title' => 'Sorento',
      ),
      11 => 
      array (
        'value' => 'SOUL',
        'title' => 'Soul',
      ),
      12 => 
      array (
        'value' => 'SPECTRA',
        'title' => 'Spectra',
      ),
      13 => 
      array (
        'value' => 'SPECTRA5',
        'title' => 'Spectra5',
      ),
      14 => 
      array (
        'value' => 'SPORTA',
        'title' => 'Sportage',
      ),
      15 => 
      array (
        'value' => 'KIAOTH',
        'title' => 'Other Kia Models',
      ),
    ),
  ),
  33 => 
  array (
    'value' => 'LAM',
    'title' => 'Lamborghini',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'AVENT',
        'title' => 'Aventador',
      ),
      1 => 
      array (
        'value' => 'COUNT',
        'title' => 'Countach',
      ),
      2 => 
      array (
        'value' => 'DIABLO',
        'title' => 'Diablo',
      ),
      3 => 
      array (
        'value' => 'GALLARDO',
        'title' => 'Gallardo',
      ),
      4 => 
      array (
        'value' => 'JALPA',
        'title' => 'Jalpa',
      ),
      5 => 
      array (
        'value' => 'LM002',
        'title' => 'LM002',
      ),
      6 => 
      array (
        'value' => 'MURCIELAGO',
        'title' => 'Murcielago',
      ),
      7 => 
      array (
        'value' => 'UNAVAILLAM',
        'title' => 'Other Lamborghini Models',
      ),
    ),
  ),
  34 => 
  array (
    'value' => 'LAN',
    'title' => 'Lancia',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'BETA',
        'title' => 'Beta',
      ),
      1 => 
      array (
        'value' => 'ZAGATO',
        'title' => 'Zagato',
      ),
      2 => 
      array (
        'value' => 'UNAVAILLAN',
        'title' => 'Other Lancia Models',
      ),
    ),
  ),
  35 => 
  array (
    'value' => 'ROV',
    'title' => 'Land Rover',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'DEFEND',
        'title' => 'Defender',
      ),
      1 => 
      array (
        'value' => 'DISCOV',
        'title' => 'Discovery',
      ),
      2 => 
      array (
        'value' => 'FRELNDR',
        'title' => 'Freelander',
      ),
      3 => 
      array (
        'value' => 'LR2',
        'title' => 'LR2',
      ),
      4 => 
      array (
        'value' => 'LR3',
        'title' => 'LR3',
      ),
      5 => 
      array (
        'value' => 'LR4',
        'title' => 'LR4',
      ),
      6 => 
      array (
        'value' => 'RANGE',
        'title' => 'Range Rover',
      ),
      7 => 
      array (
        'value' => 'EVOQUE',
        'title' => 'Range Rover Evoque',
      ),
      8 => 
      array (
        'value' => 'RANGESPORT',
        'title' => 'Range Rover Sport',
      ),
      9 => 
      array (
        'value' => 'ROVOTH',
        'title' => 'Other Land Rover Models',
      ),
    ),
  ),
  36 => 
  array (
    'value' => 'LEXUS',
    'title' => 'Lexus',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'CT_MODELS',
        'title' => 'CT Models (1)',
      ),
      1 => 
      array (
        'value' => 'CT200H',
        'title' => ' - CT 200h',
      ),
      2 => 
      array (
        'value' => 'ES_MODELS',
        'title' => 'ES Models (5)',
      ),
      3 => 
      array (
        'value' => 'ES250',
        'title' => ' - ES 250',
      ),
      4 => 
      array (
        'value' => 'ES300',
        'title' => ' - ES 300',
      ),
      5 => 
      array (
        'value' => 'ES300H',
        'title' => ' - ES 300h',
      ),
      6 => 
      array (
        'value' => 'ES330',
        'title' => ' - ES 330',
      ),
      7 => 
      array (
        'value' => 'ES350',
        'title' => ' - ES 350',
      ),
      8 => 
      array (
        'value' => 'GS_MODELS',
        'title' => 'GS Models (6)',
      ),
      9 => 
      array (
        'value' => 'GS300',
        'title' => ' - GS 300',
      ),
      10 => 
      array (
        'value' => 'GS350',
        'title' => ' - GS 350',
      ),
      11 => 
      array (
        'value' => 'GS400',
        'title' => ' - GS 400',
      ),
      12 => 
      array (
        'value' => 'GS430',
        'title' => ' - GS 430',
      ),
      13 => 
      array (
        'value' => 'GS450H',
        'title' => ' - GS 450h',
      ),
      14 => 
      array (
        'value' => 'GS460',
        'title' => ' - GS 460',
      ),
      15 => 
      array (
        'value' => 'GX_MODELS',
        'title' => 'GX Models (2)',
      ),
      16 => 
      array (
        'value' => 'GX460',
        'title' => ' - GX 460',
      ),
      17 => 
      array (
        'value' => 'GX470',
        'title' => ' - GX 470',
      ),
      18 => 
      array (
        'value' => 'HS_MODELS',
        'title' => 'HS Models (1)',
      ),
      19 => 
      array (
        'value' => 'HS250H',
        'title' => ' - HS 250h',
      ),
      20 => 
      array (
        'value' => 'IS_MODELS',
        'title' => 'IS Models (6)',
      ),
      21 => 
      array (
        'value' => 'IS250',
        'title' => ' - IS 250',
      ),
      22 => 
      array (
        'value' => 'IS250C',
        'title' => ' - IS 250C',
      ),
      23 => 
      array (
        'value' => 'IS300',
        'title' => ' - IS 300',
      ),
      24 => 
      array (
        'value' => 'IS350',
        'title' => ' - IS 350',
      ),
      25 => 
      array (
        'value' => 'IS350C',
        'title' => ' - IS 350C',
      ),
      26 => 
      array (
        'value' => 'ISF',
        'title' => ' - IS F',
      ),
      27 => 
      array (
        'value' => 'LEXLFA',
        'title' => 'LFA',
      ),
      28 => 
      array (
        'value' => 'LS_MODELS',
        'title' => 'LS Models (4)',
      ),
      29 => 
      array (
        'value' => 'LS400',
        'title' => ' - LS 400',
      ),
      30 => 
      array (
        'value' => 'LS430',
        'title' => ' - LS 430',
      ),
      31 => 
      array (
        'value' => 'LS460',
        'title' => ' - LS 460',
      ),
      32 => 
      array (
        'value' => 'LS600H',
        'title' => ' - LS 600h',
      ),
      33 => 
      array (
        'value' => 'LX_MODELS',
        'title' => 'LX Models (3)',
      ),
      34 => 
      array (
        'value' => 'LX450',
        'title' => ' - LX 450',
      ),
      35 => 
      array (
        'value' => 'LX470',
        'title' => ' - LX 470',
      ),
      36 => 
      array (
        'value' => 'LX570',
        'title' => ' - LX 570',
      ),
      37 => 
      array (
        'value' => 'RX_MODELS',
        'title' => 'RX Models (5)',
      ),
      38 => 
      array (
        'value' => 'RX300',
        'title' => ' - RX 300',
      ),
      39 => 
      array (
        'value' => 'RX330',
        'title' => ' - RX 330',
      ),
      40 => 
      array (
        'value' => 'RX350',
        'title' => ' - RX 350',
      ),
      41 => 
      array (
        'value' => 'RX400H',
        'title' => ' - RX 400h',
      ),
      42 => 
      array (
        'value' => 'RX450H',
        'title' => ' - RX 450h',
      ),
      43 => 
      array (
        'value' => 'SC_MODELS',
        'title' => 'SC Models (3)',
      ),
      44 => 
      array (
        'value' => 'SC300',
        'title' => ' - SC 300',
      ),
      45 => 
      array (
        'value' => 'SC400',
        'title' => ' - SC 400',
      ),
      46 => 
      array (
        'value' => 'SC430',
        'title' => ' - SC 430',
      ),
      47 => 
      array (
        'value' => 'LEXOTH',
        'title' => 'Other Lexus Models',
      ),
    ),
  ),
  37 => 
  array (
    'value' => 'LINC',
    'title' => 'Lincoln',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'AVIATOR',
        'title' => 'Aviator',
      ),
      1 => 
      array (
        'value' => 'BLKWOOD',
        'title' => 'Blackwood',
      ),
      2 => 
      array (
        'value' => 'CONT',
        'title' => 'Continental',
      ),
      3 => 
      array (
        'value' => 'LSLINCOLN',
        'title' => 'LS',
      ),
      4 => 
      array (
        'value' => 'MARKLT',
        'title' => 'Mark LT',
      ),
      5 => 
      array (
        'value' => 'MARK6',
        'title' => 'Mark VI',
      ),
      6 => 
      array (
        'value' => 'MARK7',
        'title' => 'Mark VII',
      ),
      7 => 
      array (
        'value' => 'MARK8',
        'title' => 'Mark VIII',
      ),
      8 => 
      array (
        'value' => 'MKS',
        'title' => 'MKS',
      ),
      9 => 
      array (
        'value' => 'MKT',
        'title' => 'MKT',
      ),
      10 => 
      array (
        'value' => 'MKX',
        'title' => 'MKX',
      ),
      11 => 
      array (
        'value' => 'MKZ',
        'title' => 'MKZ',
      ),
      12 => 
      array (
        'value' => 'NAVIGA',
        'title' => 'Navigator',
      ),
      13 => 
      array (
        'value' => 'NAVIGAL',
        'title' => 'Navigator L',
      ),
      14 => 
      array (
        'value' => 'LINCTC',
        'title' => 'Town Car',
      ),
      15 => 
      array (
        'value' => 'ZEPHYR',
        'title' => 'Zephyr',
      ),
      16 => 
      array (
        'value' => 'LINOTH',
        'title' => 'Other Lincoln Models',
      ),
    ),
  ),
  38 => 
  array (
    'value' => 'LOTUS',
    'title' => 'Lotus',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ELAN',
        'title' => 'Elan',
      ),
      1 => 
      array (
        'value' => 'LOTELISE',
        'title' => 'Elise',
      ),
      2 => 
      array (
        'value' => 'ESPRIT',
        'title' => 'Esprit',
      ),
      3 => 
      array (
        'value' => 'EVORA',
        'title' => 'Evora',
      ),
      4 => 
      array (
        'value' => 'EXIGE',
        'title' => 'Exige',
      ),
      5 => 
      array (
        'value' => 'UNAVAILLOT',
        'title' => 'Other Lotus Models',
      ),
    ),
  ),
  39 => 
  array (
    'value' => 'MAS',
    'title' => 'Maserati',
    'models' => 
    array (
      0 => 
      array (
        'value' => '430',
        'title' => '430',
      ),
      1 => 
      array (
        'value' => 'BITRBO',
        'title' => 'Biturbo',
      ),
      2 => 
      array (
        'value' => 'COUPEMAS',
        'title' => 'Coupe',
      ),
      3 => 
      array (
        'value' => 'GRANSPORT',
        'title' => 'GranSport',
      ),
      4 => 
      array (
        'value' => 'GRANTURISM',
        'title' => 'GranTurismo',
      ),
      5 => 
      array (
        'value' => 'QP',
        'title' => 'Quattroporte',
      ),
      6 => 
      array (
        'value' => 'SPYDER',
        'title' => 'Spyder',
      ),
      7 => 
      array (
        'value' => 'UNAVAILMAS',
        'title' => 'Other Maserati Models',
      ),
    ),
  ),
  40 => 
  array (
    'value' => 'MAYBACH',
    'title' => 'Maybach',
    'models' => 
    array (
      0 => 
      array (
        'value' => '57MAYBACH',
        'title' => '57',
      ),
      1 => 
      array (
        'value' => '62MAYBACH',
        'title' => '62',
      ),
      2 => 
      array (
        'value' => 'UNAVAILMAY',
        'title' => 'Other Maybach Models',
      ),
    ),
  ),
  41 => 
  array (
    'value' => 'MAZDA',
    'title' => 'Mazda',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'MAZDA323',
        'title' => '323',
      ),
      1 => 
      array (
        'value' => 'MAZDA626',
        'title' => '626',
      ),
      2 => 
      array (
        'value' => '929',
        'title' => '929',
      ),
      3 => 
      array (
        'value' => 'B-SERIES',
        'title' => 'B-Series Pickup',
      ),
      4 => 
      array (
        'value' => 'CX-5',
        'title' => 'CX-5',
      ),
      5 => 
      array (
        'value' => 'CX-7',
        'title' => 'CX-7',
      ),
      6 => 
      array (
        'value' => 'CX-9',
        'title' => 'CX-9',
      ),
      7 => 
      array (
        'value' => 'GLC',
        'title' => 'GLC',
      ),
      8 => 
      array (
        'value' => 'MAZDA2',
        'title' => 'MAZDA2',
      ),
      9 => 
      array (
        'value' => 'MAZDA3',
        'title' => 'MAZDA3',
      ),
      10 => 
      array (
        'value' => 'MAZDA5',
        'title' => 'MAZDA5',
      ),
      11 => 
      array (
        'value' => 'MAZDA6',
        'title' => 'MAZDA6',
      ),
      12 => 
      array (
        'value' => 'MAZDASPD3',
        'title' => 'MAZDASPEED3',
      ),
      13 => 
      array (
        'value' => 'MAZDASPD6',
        'title' => 'MAZDASPEED6',
      ),
      14 => 
      array (
        'value' => 'MIATA',
        'title' => 'Miata MX5',
      ),
      15 => 
      array (
        'value' => 'MILL',
        'title' => 'Millenia',
      ),
      16 => 
      array (
        'value' => 'MPV',
        'title' => 'MPV',
      ),
      17 => 
      array (
        'value' => 'MX3',
        'title' => 'MX3',
      ),
      18 => 
      array (
        'value' => 'MX6',
        'title' => 'MX6',
      ),
      19 => 
      array (
        'value' => 'NAVAJO',
        'title' => 'Navajo',
      ),
      20 => 
      array (
        'value' => 'PROTE',
        'title' => 'Protege',
      ),
      21 => 
      array (
        'value' => 'PROTE5',
        'title' => 'Protege5',
      ),
      22 => 
      array (
        'value' => 'RX7',
        'title' => 'RX-7',
      ),
      23 => 
      array (
        'value' => 'RX8',
        'title' => 'RX-8',
      ),
      24 => 
      array (
        'value' => 'TRIBUTE',
        'title' => 'Tribute',
      ),
      25 => 
      array (
        'value' => 'MAZOTH',
        'title' => 'Other Mazda Models',
      ),
    ),
  ),
  42 => 
  array (
    'value' => 'MCLAREN',
    'title' => 'McLaren',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'MP4',
        'title' => 'MP4-12C',
      ),
    ),
  ),
  43 => 
  array (
    'value' => 'MB',
    'title' => 'Mercedes-Benz',
    'models' => 
    array (
      0 => 
      array (
        'value' => '190_CLASS',
        'title' => '190 Class (2)',
      ),
      1 => 
      array (
        'value' => '190D',
        'title' => ' - 190D',
      ),
      2 => 
      array (
        'value' => '190E',
        'title' => ' - 190E',
      ),
      3 => 
      array (
        'value' => '240_CLASS',
        'title' => '240 Class (1)',
      ),
      4 => 
      array (
        'value' => '240D',
        'title' => ' - 240D',
      ),
      5 => 
      array (
        'value' => '300_CLASS_E_CLASS',
        'title' => '300 Class / E Class (6)',
      ),
      6 => 
      array (
        'value' => '300CD',
        'title' => ' - 300CD',
      ),
      7 => 
      array (
        'value' => '300CE',
        'title' => ' - 300CE',
      ),
      8 => 
      array (
        'value' => '300D',
        'title' => ' - 300D',
      ),
      9 => 
      array (
        'value' => '300E',
        'title' => ' - 300E',
      ),
      10 => 
      array (
        'value' => '300TD',
        'title' => ' - 300TD',
      ),
      11 => 
      array (
        'value' => '300TE',
        'title' => ' - 300TE',
      ),
      12 => 
      array (
        'value' => 'C_CLASS',
        'title' => 'C Class (13)',
      ),
      13 => 
      array (
        'value' => 'C220',
        'title' => ' - C220',
      ),
      14 => 
      array (
        'value' => 'C230',
        'title' => ' - C230',
      ),
      15 => 
      array (
        'value' => 'C240',
        'title' => ' - C240',
      ),
      16 => 
      array (
        'value' => 'C250',
        'title' => ' - C250',
      ),
      17 => 
      array (
        'value' => 'C280',
        'title' => ' - C280',
      ),
      18 => 
      array (
        'value' => 'C300',
        'title' => ' - C300',
      ),
      19 => 
      array (
        'value' => 'C320',
        'title' => ' - C320',
      ),
      20 => 
      array (
        'value' => 'C32AMG',
        'title' => ' - C32 AMG',
      ),
      21 => 
      array (
        'value' => 'C350',
        'title' => ' - C350',
      ),
      22 => 
      array (
        'value' => 'C36AMG',
        'title' => ' - C36 AMG',
      ),
      23 => 
      array (
        'value' => 'C43AMG',
        'title' => ' - C43 AMG',
      ),
      24 => 
      array (
        'value' => 'C55AMG',
        'title' => ' - C55 AMG',
      ),
      25 => 
      array (
        'value' => 'C63AMG',
        'title' => ' - C63 AMG',
      ),
      26 => 
      array (
        'value' => 'CL_CLASS',
        'title' => 'CL Class (6)',
      ),
      27 => 
      array (
        'value' => 'CL500',
        'title' => ' - CL500',
      ),
      28 => 
      array (
        'value' => 'CL550',
        'title' => ' - CL550',
      ),
      29 => 
      array (
        'value' => 'CL55AMG',
        'title' => ' - CL55 AMG',
      ),
      30 => 
      array (
        'value' => 'CL600',
        'title' => ' - CL600',
      ),
      31 => 
      array (
        'value' => 'CL63AMG',
        'title' => ' - CL63 AMG',
      ),
      32 => 
      array (
        'value' => 'CL65AMG',
        'title' => ' - CL65 AMG',
      ),
      33 => 
      array (
        'value' => 'CLK_CLASS',
        'title' => 'CLK Class (7)',
      ),
      34 => 
      array (
        'value' => 'CLK320',
        'title' => ' - CLK320',
      ),
      35 => 
      array (
        'value' => 'CLK350',
        'title' => ' - CLK350',
      ),
      36 => 
      array (
        'value' => 'CLK430',
        'title' => ' - CLK430',
      ),
      37 => 
      array (
        'value' => 'CLK500',
        'title' => ' - CLK500',
      ),
      38 => 
      array (
        'value' => 'CLK550',
        'title' => ' - CLK550',
      ),
      39 => 
      array (
        'value' => 'CLK55AMG',
        'title' => ' - CLK55 AMG',
      ),
      40 => 
      array (
        'value' => 'CLK63AMG',
        'title' => ' - CLK63 AMG',
      ),
      41 => 
      array (
        'value' => 'CLS_CLASS',
        'title' => 'CLS Class (4)',
      ),
      42 => 
      array (
        'value' => 'CLS500',
        'title' => ' - CLS500',
      ),
      43 => 
      array (
        'value' => 'CLS550',
        'title' => ' - CLS550',
      ),
      44 => 
      array (
        'value' => 'CLS55AMG',
        'title' => ' - CLS55 AMG',
      ),
      45 => 
      array (
        'value' => 'CLS63AMG',
        'title' => ' - CLS63 AMG',
      ),
      46 => 
      array (
        'value' => 'E_CLASS',
        'title' => 'E Class (18)',
      ),
      47 => 
      array (
        'value' => '260E',
        'title' => ' - 260E',
      ),
      48 => 
      array (
        'value' => '280CE',
        'title' => ' - 280CE',
      ),
      49 => 
      array (
        'value' => '280E',
        'title' => ' - 280E',
      ),
      50 => 
      array (
        'value' => '400E',
        'title' => ' - 400E',
      ),
      51 => 
      array (
        'value' => '500E',
        'title' => ' - 500E',
      ),
      52 => 
      array (
        'value' => 'E300',
        'title' => ' - E300',
      ),
      53 => 
      array (
        'value' => 'E320',
        'title' => ' - E320',
      ),
      54 => 
      array (
        'value' => 'E320BLUE',
        'title' => ' - E320 Bluetec',
      ),
      55 => 
      array (
        'value' => 'E320CDI',
        'title' => ' - E320 CDI',
      ),
      56 => 
      array (
        'value' => 'E350',
        'title' => ' - E350',
      ),
      57 => 
      array (
        'value' => 'E350BLUE',
        'title' => ' - E350 Bluetec',
      ),
      58 => 
      array (
        'value' => 'E400',
        'title' => ' - E400 Hybrid',
      ),
      59 => 
      array (
        'value' => 'E420',
        'title' => ' - E420',
      ),
      60 => 
      array (
        'value' => 'E430',
        'title' => ' - E430',
      ),
      61 => 
      array (
        'value' => 'E500',
        'title' => ' - E500',
      ),
      62 => 
      array (
        'value' => 'E550',
        'title' => ' - E550',
      ),
      63 => 
      array (
        'value' => 'E55AMG',
        'title' => ' - E55 AMG',
      ),
      64 => 
      array (
        'value' => 'E63AMG',
        'title' => ' - E63 AMG',
      ),
      65 => 
      array (
        'value' => 'G_CLASS',
        'title' => 'G Class (4)',
      ),
      66 => 
      array (
        'value' => 'G500',
        'title' => ' - G500',
      ),
      67 => 
      array (
        'value' => 'G550',
        'title' => ' - G550',
      ),
      68 => 
      array (
        'value' => 'G55AMG',
        'title' => ' - G55 AMG',
      ),
      69 => 
      array (
        'value' => 'G63AMG',
        'title' => ' - G63 AMG',
      ),
      70 => 
      array (
        'value' => 'GL_CLASS',
        'title' => 'GL Class (5)',
      ),
      71 => 
      array (
        'value' => 'GL320BLUE',
        'title' => ' - GL320 Bluetec',
      ),
      72 => 
      array (
        'value' => 'GL320CDI',
        'title' => ' - GL320 CDI',
      ),
      73 => 
      array (
        'value' => 'GL350BLUE',
        'title' => ' - GL350 Bluetec',
      ),
      74 => 
      array (
        'value' => 'GL450',
        'title' => ' - GL450',
      ),
      75 => 
      array (
        'value' => 'GL550',
        'title' => ' - GL550',
      ),
      76 => 
      array (
        'value' => 'GLK_CLASS',
        'title' => 'GLK Class (1)',
      ),
      77 => 
      array (
        'value' => 'GLK350',
        'title' => ' - GLK350',
      ),
      78 => 
      array (
        'value' => 'M_CLASS',
        'title' => 'M Class (11)',
      ),
      79 => 
      array (
        'value' => 'ML320',
        'title' => ' - ML320',
      ),
      80 => 
      array (
        'value' => 'ML320BLUE',
        'title' => ' - ML320 Bluetec',
      ),
      81 => 
      array (
        'value' => 'ML320CDI',
        'title' => ' - ML320 CDI',
      ),
      82 => 
      array (
        'value' => 'ML350',
        'title' => ' - ML350',
      ),
      83 => 
      array (
        'value' => 'ML350BLUE',
        'title' => ' - ML350 Bluetec',
      ),
      84 => 
      array (
        'value' => 'ML430',
        'title' => ' - ML430',
      ),
      85 => 
      array (
        'value' => 'ML450HY',
        'title' => ' - ML450 Hybrid',
      ),
      86 => 
      array (
        'value' => 'ML500',
        'title' => ' - ML500',
      ),
      87 => 
      array (
        'value' => 'ML550',
        'title' => ' - ML550',
      ),
      88 => 
      array (
        'value' => 'ML55AMG',
        'title' => ' - ML55 AMG',
      ),
      89 => 
      array (
        'value' => 'ML63AMG',
        'title' => ' - ML63 AMG',
      ),
      90 => 
      array (
        'value' => 'R_CLASS',
        'title' => 'R Class (6)',
      ),
      91 => 
      array (
        'value' => 'R320BLUE',
        'title' => ' - R320 Bluetec',
      ),
      92 => 
      array (
        'value' => 'R320CDI',
        'title' => ' - R320 CDI',
      ),
      93 => 
      array (
        'value' => 'R350',
        'title' => ' - R350',
      ),
      94 => 
      array (
        'value' => 'R350BLUE',
        'title' => ' - R350 Bluetec',
      ),
      95 => 
      array (
        'value' => 'R500',
        'title' => ' - R500',
      ),
      96 => 
      array (
        'value' => 'R63AMG',
        'title' => ' - R63 AMG',
      ),
      97 => 
      array (
        'value' => 'S_CLASS',
        'title' => 'S Class (30)',
      ),
      98 => 
      array (
        'value' => '300SD',
        'title' => ' - 300SD',
      ),
      99 => 
      array (
        'value' => '300SDL',
        'title' => ' - 300SDL',
      ),
      100 => 
      array (
        'value' => '300SE',
        'title' => ' - 300SE',
      ),
      101 => 
      array (
        'value' => '300SEL',
        'title' => ' - 300SEL',
      ),
      102 => 
      array (
        'value' => '350SD',
        'title' => ' - 350SD',
      ),
      103 => 
      array (
        'value' => '350SDL',
        'title' => ' - 350SDL',
      ),
      104 => 
      array (
        'value' => '380SE',
        'title' => ' - 380SE',
      ),
      105 => 
      array (
        'value' => '380SEC',
        'title' => ' - 380SEC',
      ),
      106 => 
      array (
        'value' => '380SEL',
        'title' => ' - 380SEL',
      ),
      107 => 
      array (
        'value' => '400SE',
        'title' => ' - 400SE',
      ),
      108 => 
      array (
        'value' => '400SEL',
        'title' => ' - 400SEL',
      ),
      109 => 
      array (
        'value' => '420SEL',
        'title' => ' - 420SEL',
      ),
      110 => 
      array (
        'value' => '500SEC',
        'title' => ' - 500SEC',
      ),
      111 => 
      array (
        'value' => '500SEL',
        'title' => ' - 500SEL',
      ),
      112 => 
      array (
        'value' => '560SEC',
        'title' => ' - 560SEC',
      ),
      113 => 
      array (
        'value' => '560SEL',
        'title' => ' - 560SEL',
      ),
      114 => 
      array (
        'value' => '600SEC',
        'title' => ' - 600SEC',
      ),
      115 => 
      array (
        'value' => '600SEL',
        'title' => ' - 600SEL',
      ),
      116 => 
      array (
        'value' => 'S320',
        'title' => ' - S320',
      ),
      117 => 
      array (
        'value' => 'S350',
        'title' => ' - S350',
      ),
      118 => 
      array (
        'value' => 'S350BLUE',
        'title' => ' - S350 Bluetec',
      ),
      119 => 
      array (
        'value' => 'S400HY',
        'title' => ' - S400 Hybrid',
      ),
      120 => 
      array (
        'value' => 'S420',
        'title' => ' - S420',
      ),
      121 => 
      array (
        'value' => 'S430',
        'title' => ' - S430',
      ),
      122 => 
      array (
        'value' => 'S500',
        'title' => ' - S500',
      ),
      123 => 
      array (
        'value' => 'S550',
        'title' => ' - S550',
      ),
      124 => 
      array (
        'value' => 'S55AMG',
        'title' => ' - S55 AMG',
      ),
      125 => 
      array (
        'value' => 'S600',
        'title' => ' - S600',
      ),
      126 => 
      array (
        'value' => 'S63AMG',
        'title' => ' - S63 AMG',
      ),
      127 => 
      array (
        'value' => 'S65AMG',
        'title' => ' - S65 AMG',
      ),
      128 => 
      array (
        'value' => 'SL_CLASS',
        'title' => 'SL Class (13)',
      ),
      129 => 
      array (
        'value' => '300SL',
        'title' => ' - 300SL',
      ),
      130 => 
      array (
        'value' => '380SL',
        'title' => ' - 380SL',
      ),
      131 => 
      array (
        'value' => '380SLC',
        'title' => ' - 380SLC',
      ),
      132 => 
      array (
        'value' => '500SL',
        'title' => ' - 500SL',
      ),
      133 => 
      array (
        'value' => '560SL',
        'title' => ' - 560SL',
      ),
      134 => 
      array (
        'value' => '600SL',
        'title' => ' - 600SL',
      ),
      135 => 
      array (
        'value' => 'SL320',
        'title' => ' - SL320',
      ),
      136 => 
      array (
        'value' => 'SL500',
        'title' => ' - SL500',
      ),
      137 => 
      array (
        'value' => 'SL550',
        'title' => ' - SL550',
      ),
      138 => 
      array (
        'value' => 'SL55AMG',
        'title' => ' - SL55 AMG',
      ),
      139 => 
      array (
        'value' => 'SL600',
        'title' => ' - SL600',
      ),
      140 => 
      array (
        'value' => 'SL63AMG',
        'title' => ' - SL63 AMG',
      ),
      141 => 
      array (
        'value' => 'SL65AMG',
        'title' => ' - SL65 AMG',
      ),
      142 => 
      array (
        'value' => 'SLK_CLASS',
        'title' => 'SLK Class (8)',
      ),
      143 => 
      array (
        'value' => 'SLK230',
        'title' => ' - SLK230',
      ),
      144 => 
      array (
        'value' => 'SLK250',
        'title' => ' - SLK250',
      ),
      145 => 
      array (
        'value' => 'SLK280',
        'title' => ' - SLK280',
      ),
      146 => 
      array (
        'value' => 'SLK300',
        'title' => ' - SLK300',
      ),
      147 => 
      array (
        'value' => 'SLK320',
        'title' => ' - SLK320',
      ),
      148 => 
      array (
        'value' => 'SLK32AMG',
        'title' => ' - SLK32 AMG',
      ),
      149 => 
      array (
        'value' => 'SLK350',
        'title' => ' - SLK350',
      ),
      150 => 
      array (
        'value' => 'SLK55AMG',
        'title' => ' - SLK55 AMG',
      ),
      151 => 
      array (
        'value' => 'SLR_CLASS',
        'title' => 'SLR Class (1)',
      ),
      152 => 
      array (
        'value' => 'SLR',
        'title' => ' - SLR',
      ),
      153 => 
      array (
        'value' => 'SLS_CLASS',
        'title' => 'SLS Class (1)',
      ),
      154 => 
      array (
        'value' => 'SLSAMG',
        'title' => ' - SLS AMG',
      ),
      155 => 
      array (
        'value' => 'SPRINTER_CLASS',
        'title' => 'Sprinter Class (1)',
      ),
      156 => 
      array (
        'value' => 'MBSPRINTER',
        'title' => ' - Sprinter',
      ),
      157 => 
      array (
        'value' => 'MBOTH',
        'title' => 'Other Mercedes-Benz Models',
      ),
    ),
  ),
  44 => 
  array (
    'value' => 'MERC',
    'title' => 'Mercury',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'CAPRI',
        'title' => 'Capri',
      ),
      1 => 
      array (
        'value' => 'COUGAR',
        'title' => 'Cougar',
      ),
      2 => 
      array (
        'value' => 'MERCGRAND',
        'title' => 'Grand Marquis',
      ),
      3 => 
      array (
        'value' => 'LYNX',
        'title' => 'Lynx',
      ),
      4 => 
      array (
        'value' => 'MARAUDER',
        'title' => 'Marauder',
      ),
      5 => 
      array (
        'value' => 'MARINER',
        'title' => 'Mariner',
      ),
      6 => 
      array (
        'value' => 'MARQ',
        'title' => 'Marquis',
      ),
      7 => 
      array (
        'value' => 'MILAN',
        'title' => 'Milan',
      ),
      8 => 
      array (
        'value' => 'MONTEGO',
        'title' => 'Montego',
      ),
      9 => 
      array (
        'value' => 'MONTEREY',
        'title' => 'Monterey',
      ),
      10 => 
      array (
        'value' => 'MOUNTA',
        'title' => 'Mountaineer',
      ),
      11 => 
      array (
        'value' => 'MYSTIQ',
        'title' => 'Mystique',
      ),
      12 => 
      array (
        'value' => 'SABLE',
        'title' => 'Sable',
      ),
      13 => 
      array (
        'value' => 'TOPAZ',
        'title' => 'Topaz',
      ),
      14 => 
      array (
        'value' => 'TRACER',
        'title' => 'Tracer',
      ),
      15 => 
      array (
        'value' => 'VILLA',
        'title' => 'Villager',
      ),
      16 => 
      array (
        'value' => 'MERCZEP',
        'title' => 'Zephyr',
      ),
      17 => 
      array (
        'value' => 'MEOTH',
        'title' => 'Other Mercury Models',
      ),
    ),
  ),
  45 => 
  array (
    'value' => 'MERKUR',
    'title' => 'Merkur',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'SCORP',
        'title' => 'Scorpio',
      ),
      1 => 
      array (
        'value' => 'XR4TI',
        'title' => 'XR4Ti',
      ),
      2 => 
      array (
        'value' => 'MEROTH',
        'title' => 'Other Merkur Models',
      ),
    ),
  ),
  46 => 
  array (
    'value' => 'MINI',
    'title' => 'MINI',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'COOPRCLUB_MODELS',
        'title' => 'Cooper Clubman Models (2)',
      ),
      1 => 
      array (
        'value' => 'COOPERCLUB',
        'title' => ' - Cooper Clubman',
      ),
      2 => 
      array (
        'value' => 'COOPRCLUBS',
        'title' => ' - Cooper S Clubman',
      ),
      3 => 
      array (
        'value' => 'COOPCOUNTRY_MODELS',
        'title' => 'Cooper Countryman Models (2)',
      ),
      4 => 
      array (
        'value' => 'COUNTRYMAN',
        'title' => ' - Cooper Countryman',
      ),
      5 => 
      array (
        'value' => 'COUNTRYMNS',
        'title' => ' - Cooper S Countryman',
      ),
      6 => 
      array (
        'value' => 'COOPCOUP_MODELS',
        'title' => 'Cooper Coupe Models (2)',
      ),
      7 => 
      array (
        'value' => 'MINICOUPE',
        'title' => ' - Cooper Coupe',
      ),
      8 => 
      array (
        'value' => 'MINISCOUPE',
        'title' => ' - Cooper S Coupe',
      ),
      9 => 
      array (
        'value' => 'COOPER_MODELS',
        'title' => 'Cooper Models (2)',
      ),
      10 => 
      array (
        'value' => 'COOPER',
        'title' => ' - Cooper',
      ),
      11 => 
      array (
        'value' => 'COOPERS',
        'title' => ' - Cooper S',
      ),
      12 => 
      array (
        'value' => 'COOPRROAD_MODELS',
        'title' => 'Cooper Roadster Models (2)',
      ),
      13 => 
      array (
        'value' => 'COOPERROAD',
        'title' => ' - Cooper Roadster',
      ),
      14 => 
      array (
        'value' => 'COOPERSRD',
        'title' => ' - Cooper S Roadster',
      ),
    ),
  ),
  47 => 
  array (
    'value' => 'MIT',
    'title' => 'Mitsubishi',
    'models' => 
    array (
      0 => 
      array (
        'value' => '3000GT',
        'title' => '3000GT',
      ),
      1 => 
      array (
        'value' => 'CORD',
        'title' => 'Cordia',
      ),
      2 => 
      array (
        'value' => 'DIAMAN',
        'title' => 'Diamante',
      ),
      3 => 
      array (
        'value' => 'ECLIP',
        'title' => 'Eclipse',
      ),
      4 => 
      array (
        'value' => 'ENDEAVOR',
        'title' => 'Endeavor',
      ),
      5 => 
      array (
        'value' => 'MITEXP',
        'title' => 'Expo',
      ),
      6 => 
      array (
        'value' => 'GALANT',
        'title' => 'Galant',
      ),
      7 => 
      array (
        'value' => 'MITI',
        'title' => 'i',
      ),
      8 => 
      array (
        'value' => 'LANCERMITS',
        'title' => 'Lancer',
      ),
      9 => 
      array (
        'value' => 'LANCEREVO',
        'title' => 'Lancer Evolution',
      ),
      10 => 
      array (
        'value' => 'MITPU',
        'title' => 'Mighty Max',
      ),
      11 => 
      array (
        'value' => 'MIRAGE',
        'title' => 'Mirage',
      ),
      12 => 
      array (
        'value' => 'MONT',
        'title' => 'Montero',
      ),
      13 => 
      array (
        'value' => 'MONTSPORT',
        'title' => 'Montero Sport',
      ),
      14 => 
      array (
        'value' => 'OUTLANDER',
        'title' => 'Outlander',
      ),
      15 => 
      array (
        'value' => 'OUTLANDSPT',
        'title' => 'Outlander Sport',
      ),
      16 => 
      array (
        'value' => 'PRECIS',
        'title' => 'Precis',
      ),
      17 => 
      array (
        'value' => 'RAIDERMITS',
        'title' => 'Raider',
      ),
      18 => 
      array (
        'value' => 'SIGMA',
        'title' => 'Sigma',
      ),
      19 => 
      array (
        'value' => 'MITSTAR',
        'title' => 'Starion',
      ),
      20 => 
      array (
        'value' => 'TRED',
        'title' => 'Tredia',
      ),
      21 => 
      array (
        'value' => 'MITVAN',
        'title' => 'Van',
      ),
      22 => 
      array (
        'value' => 'MITOTH',
        'title' => 'Other Mitsubishi Models',
      ),
    ),
  ),
  48 => 
  array (
    'value' => 'NISSAN',
    'title' => 'Nissan',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'NIS200SX',
        'title' => '200SX',
      ),
      1 => 
      array (
        'value' => '240SX',
        'title' => '240SX',
      ),
      2 => 
      array (
        'value' => '300ZXTURBO',
        'title' => '300ZX',
      ),
      3 => 
      array (
        'value' => '350Z',
        'title' => '350Z',
      ),
      4 => 
      array (
        'value' => '370Z',
        'title' => '370Z',
      ),
      5 => 
      array (
        'value' => 'ALTIMA',
        'title' => 'Altima',
      ),
      6 => 
      array (
        'value' => 'PATHARMADA',
        'title' => 'Armada',
      ),
      7 => 
      array (
        'value' => 'AXXESS',
        'title' => 'Axxess',
      ),
      8 => 
      array (
        'value' => 'CUBE',
        'title' => 'Cube',
      ),
      9 => 
      array (
        'value' => 'FRONTI',
        'title' => 'Frontier',
      ),
      10 => 
      array (
        'value' => 'GT-R',
        'title' => 'GT-R',
      ),
      11 => 
      array (
        'value' => 'JUKE',
        'title' => 'Juke',
      ),
      12 => 
      array (
        'value' => 'LEAF',
        'title' => 'Leaf',
      ),
      13 => 
      array (
        'value' => 'MAX',
        'title' => 'Maxima',
      ),
      14 => 
      array (
        'value' => 'MURANO',
        'title' => 'Murano',
      ),
      15 => 
      array (
        'value' => 'MURANOCROS',
        'title' => 'Murano CrossCabriolet',
      ),
      16 => 
      array (
        'value' => 'NV',
        'title' => 'NV',
      ),
      17 => 
      array (
        'value' => 'NX',
        'title' => 'NX',
      ),
      18 => 
      array (
        'value' => 'PATH',
        'title' => 'Pathfinder',
      ),
      19 => 
      array (
        'value' => 'NISPU',
        'title' => 'Pickup',
      ),
      20 => 
      array (
        'value' => 'PULSAR',
        'title' => 'Pulsar',
      ),
      21 => 
      array (
        'value' => 'QUEST',
        'title' => 'Quest',
      ),
      22 => 
      array (
        'value' => 'ROGUE',
        'title' => 'Rogue',
      ),
      23 => 
      array (
        'value' => 'SENTRA',
        'title' => 'Sentra',
      ),
      24 => 
      array (
        'value' => 'STANZA',
        'title' => 'Stanza',
      ),
      25 => 
      array (
        'value' => 'TITAN',
        'title' => 'Titan',
      ),
      26 => 
      array (
        'value' => 'NISVAN',
        'title' => 'Van',
      ),
      27 => 
      array (
        'value' => 'VERSA',
        'title' => 'Versa',
      ),
      28 => 
      array (
        'value' => 'XTERRA',
        'title' => 'Xterra',
      ),
      29 => 
      array (
        'value' => 'NISSOTH',
        'title' => 'Other Nissan Models',
      ),
    ),
  ),
  49 => 
  array (
    'value' => 'OLDS',
    'title' => 'Oldsmobile',
    'models' => 
    array (
      0 => 
      array (
        'value' => '88',
        'title' => '88',
      ),
      1 => 
      array (
        'value' => 'ACHIEV',
        'title' => 'Achieva',
      ),
      2 => 
      array (
        'value' => 'ALERO',
        'title' => 'Alero',
      ),
      3 => 
      array (
        'value' => 'AURORA',
        'title' => 'Aurora',
      ),
      4 => 
      array (
        'value' => 'BRAV',
        'title' => 'Bravada',
      ),
      5 => 
      array (
        'value' => 'CUCR',
        'title' => 'Custom Cruiser',
      ),
      6 => 
      array (
        'value' => 'OLDCUS',
        'title' => 'Cutlass',
      ),
      7 => 
      array (
        'value' => 'OLDCALAIS',
        'title' => 'Cutlass Calais',
      ),
      8 => 
      array (
        'value' => 'CIERA',
        'title' => 'Cutlass Ciera',
      ),
      9 => 
      array (
        'value' => 'CSUPR',
        'title' => 'Cutlass Supreme',
      ),
      10 => 
      array (
        'value' => 'OLDSFIR',
        'title' => 'Firenza',
      ),
      11 => 
      array (
        'value' => 'INTRIG',
        'title' => 'Intrigue',
      ),
      12 => 
      array (
        'value' => '98',
        'title' => 'Ninety-Eight',
      ),
      13 => 
      array (
        'value' => 'OMEG',
        'title' => 'Omega',
      ),
      14 => 
      array (
        'value' => 'REGEN',
        'title' => 'Regency',
      ),
      15 => 
      array (
        'value' => 'SILHO',
        'title' => 'Silhouette',
      ),
      16 => 
      array (
        'value' => 'TORO',
        'title' => 'Toronado',
      ),
      17 => 
      array (
        'value' => 'OLDOTH',
        'title' => 'Other Oldsmobile Models',
      ),
    ),
  ),
  50 => 
  array (
    'value' => 'PEUG',
    'title' => 'Peugeot',
    'models' => 
    array (
      0 => 
      array (
        'value' => '405',
        'title' => '405',
      ),
      1 => 
      array (
        'value' => '504',
        'title' => '504',
      ),
      2 => 
      array (
        'value' => '505',
        'title' => '505',
      ),
      3 => 
      array (
        'value' => '604',
        'title' => '604',
      ),
      4 => 
      array (
        'value' => 'UNAVAILPEU',
        'title' => 'Other Peugeot Models',
      ),
    ),
  ),
  51 => 
  array (
    'value' => 'PLYM',
    'title' => 'Plymouth',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ACC',
        'title' => 'Acclaim',
      ),
      1 => 
      array (
        'value' => 'ARROW',
        'title' => 'Arrow',
      ),
      2 => 
      array (
        'value' => 'BREEZE',
        'title' => 'Breeze',
      ),
      3 => 
      array (
        'value' => 'CARAVE',
        'title' => 'Caravelle',
      ),
      4 => 
      array (
        'value' => 'CHAMP',
        'title' => 'Champ',
      ),
      5 => 
      array (
        'value' => 'COLT',
        'title' => 'Colt',
      ),
      6 => 
      array (
        'value' => 'PLYMCONQ',
        'title' => 'Conquest',
      ),
      7 => 
      array (
        'value' => 'GRANFURY',
        'title' => 'Gran Fury',
      ),
      8 => 
      array (
        'value' => 'PLYMGRANV',
        'title' => 'Grand Voyager',
      ),
      9 => 
      array (
        'value' => 'HORI',
        'title' => 'Horizon',
      ),
      10 => 
      array (
        'value' => 'LASER',
        'title' => 'Laser',
      ),
      11 => 
      array (
        'value' => 'NEON',
        'title' => 'Neon',
      ),
      12 => 
      array (
        'value' => 'PROWLE',
        'title' => 'Prowler',
      ),
      13 => 
      array (
        'value' => 'RELI',
        'title' => 'Reliant',
      ),
      14 => 
      array (
        'value' => 'SAPPOROPLY',
        'title' => 'Sapporo',
      ),
      15 => 
      array (
        'value' => 'SCAMP',
        'title' => 'Scamp',
      ),
      16 => 
      array (
        'value' => 'SUNDAN',
        'title' => 'Sundance',
      ),
      17 => 
      array (
        'value' => 'TRAILDUST',
        'title' => 'Trailduster',
      ),
      18 => 
      array (
        'value' => 'VOYA',
        'title' => 'Voyager',
      ),
      19 => 
      array (
        'value' => 'PLYOTH',
        'title' => 'Other Plymouth Models',
      ),
    ),
  ),
  52 => 
  array (
    'value' => 'PONT',
    'title' => 'Pontiac',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'T-1000',
        'title' => '1000',
      ),
      1 => 
      array (
        'value' => '6000',
        'title' => '6000',
      ),
      2 => 
      array (
        'value' => 'AZTEK',
        'title' => 'Aztek',
      ),
      3 => 
      array (
        'value' => 'BON',
        'title' => 'Bonneville',
      ),
      4 => 
      array (
        'value' => 'CATALINA',
        'title' => 'Catalina',
      ),
      5 => 
      array (
        'value' => 'FIERO',
        'title' => 'Fiero',
      ),
      6 => 
      array (
        'value' => 'FBIRD',
        'title' => 'Firebird',
      ),
      7 => 
      array (
        'value' => 'G3',
        'title' => 'G3',
      ),
      8 => 
      array (
        'value' => 'G5',
        'title' => 'G5',
      ),
      9 => 
      array (
        'value' => 'G6',
        'title' => 'G6',
      ),
      10 => 
      array (
        'value' => 'G8',
        'title' => 'G8',
      ),
      11 => 
      array (
        'value' => 'GRNDAM',
        'title' => 'Grand Am',
      ),
      12 => 
      array (
        'value' => 'GP',
        'title' => 'Grand Prix',
      ),
      13 => 
      array (
        'value' => 'GTO',
        'title' => 'GTO',
      ),
      14 => 
      array (
        'value' => 'J2000',
        'title' => 'J2000',
      ),
      15 => 
      array (
        'value' => 'LEMANS',
        'title' => 'Le Mans',
      ),
      16 => 
      array (
        'value' => 'MONTANA',
        'title' => 'Montana',
      ),
      17 => 
      array (
        'value' => 'PARISI',
        'title' => 'Parisienne',
      ),
      18 => 
      array (
        'value' => 'PHOENIX',
        'title' => 'Phoenix',
      ),
      19 => 
      array (
        'value' => 'SAFARIPONT',
        'title' => 'Safari',
      ),
      20 => 
      array (
        'value' => 'SOLSTICE',
        'title' => 'Solstice',
      ),
      21 => 
      array (
        'value' => 'SUNBIR',
        'title' => 'Sunbird',
      ),
      22 => 
      array (
        'value' => 'SUNFIR',
        'title' => 'Sunfire',
      ),
      23 => 
      array (
        'value' => 'TORRENT',
        'title' => 'Torrent',
      ),
      24 => 
      array (
        'value' => 'TS',
        'title' => 'Trans Sport',
      ),
      25 => 
      array (
        'value' => 'VIBE',
        'title' => 'Vibe',
      ),
      26 => 
      array (
        'value' => 'PONOTH',
        'title' => 'Other Pontiac Models',
      ),
    ),
  ),
  53 => 
  array (
    'value' => 'POR',
    'title' => 'Porsche',
    'models' => 
    array (
      0 => 
      array (
        'value' => '911',
        'title' => '911',
      ),
      1 => 
      array (
        'value' => '924',
        'title' => '924',
      ),
      2 => 
      array (
        'value' => '928',
        'title' => '928',
      ),
      3 => 
      array (
        'value' => '944',
        'title' => '944',
      ),
      4 => 
      array (
        'value' => '968',
        'title' => '968',
      ),
      5 => 
      array (
        'value' => 'BOXSTE',
        'title' => 'Boxster',
      ),
      6 => 
      array (
        'value' => 'CARRERAGT',
        'title' => 'Carrera GT',
      ),
      7 => 
      array (
        'value' => 'CAYENNE',
        'title' => 'Cayenne',
      ),
      8 => 
      array (
        'value' => 'CAYMAN',
        'title' => 'Cayman',
      ),
      9 => 
      array (
        'value' => 'PANAMERA',
        'title' => 'Panamera',
      ),
      10 => 
      array (
        'value' => 'POROTH',
        'title' => 'Other Porsche Models',
      ),
    ),
  ),
  54 => 
  array (
    'value' => 'RAM',
    'title' => 'RAM',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'RAM1504WD',
        'title' => '1500',
      ),
      1 => 
      array (
        'value' => 'RAM25002WD',
        'title' => '2500',
      ),
      2 => 
      array (
        'value' => 'RAM3502WD',
        'title' => '3500',
      ),
      3 => 
      array (
        'value' => 'RAM4500',
        'title' => '4500',
      ),
    ),
  ),
  55 => 
  array (
    'value' => 'REN',
    'title' => 'Renault',
    'models' => 
    array (
      0 => 
      array (
        'value' => '18I',
        'title' => '18i',
      ),
      1 => 
      array (
        'value' => 'FU',
        'title' => 'Fuego',
      ),
      2 => 
      array (
        'value' => 'LECAR',
        'title' => 'Le Car',
      ),
      3 => 
      array (
        'value' => 'R18',
        'title' => 'R18',
      ),
      4 => 
      array (
        'value' => 'RENSPORT',
        'title' => 'Sportwagon',
      ),
      5 => 
      array (
        'value' => 'UNAVAILREN',
        'title' => 'Other Renault Models',
      ),
    ),
  ),
  56 => 
  array (
    'value' => 'RR',
    'title' => 'Rolls-Royce',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'CAMAR',
        'title' => 'Camargue',
      ),
      1 => 
      array (
        'value' => 'CORN',
        'title' => 'Corniche',
      ),
      2 => 
      array (
        'value' => 'GHOST',
        'title' => 'Ghost',
      ),
      3 => 
      array (
        'value' => 'PARKWARD',
        'title' => 'Park Ward',
      ),
      4 => 
      array (
        'value' => 'PHANT',
        'title' => 'Phantom',
      ),
      5 => 
      array (
        'value' => 'DAWN',
        'title' => 'Silver Dawn',
      ),
      6 => 
      array (
        'value' => 'SILSERAPH',
        'title' => 'Silver Seraph',
      ),
      7 => 
      array (
        'value' => 'RRSPIR',
        'title' => 'Silver Spirit',
      ),
      8 => 
      array (
        'value' => 'SPUR',
        'title' => 'Silver Spur',
      ),
      9 => 
      array (
        'value' => 'UNAVAILRR',
        'title' => 'Other Rolls-Royce Models',
      ),
    ),
  ),
  57 => 
  array (
    'value' => 'SAAB',
    'title' => 'Saab',
    'models' => 
    array (
      0 => 
      array (
        'value' => '9-2X',
        'title' => '9-2X',
      ),
      1 => 
      array (
        'value' => '9-3',
        'title' => '9-3',
      ),
      2 => 
      array (
        'value' => '9-4X',
        'title' => '9-4X',
      ),
      3 => 
      array (
        'value' => '9-5',
        'title' => '9-5',
      ),
      4 => 
      array (
        'value' => '97X',
        'title' => '9-7X',
      ),
      5 => 
      array (
        'value' => '900',
        'title' => '900',
      ),
      6 => 
      array (
        'value' => '9000',
        'title' => '9000',
      ),
      7 => 
      array (
        'value' => 'SAOTH',
        'title' => 'Other Saab Models',
      ),
    ),
  ),
  58 => 
  array (
    'value' => 'SATURN',
    'title' => 'Saturn',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ASTRA',
        'title' => 'Astra',
      ),
      1 => 
      array (
        'value' => 'AURA',
        'title' => 'Aura',
      ),
      2 => 
      array (
        'value' => 'ION',
        'title' => 'ION',
      ),
      3 => 
      array (
        'value' => 'L_SERIES',
        'title' => 'L Series (3)',
      ),
      4 => 
      array (
        'value' => 'L100',
        'title' => ' - L100',
      ),
      5 => 
      array (
        'value' => 'L200',
        'title' => ' - L200',
      ),
      6 => 
      array (
        'value' => 'L300',
        'title' => ' - L300',
      ),
      7 => 
      array (
        'value' => 'LSSATURN',
        'title' => 'LS',
      ),
      8 => 
      array (
        'value' => 'LW_SERIES',
        'title' => 'LW Series (4)',
      ),
      9 => 
      array (
        'value' => 'LW',
        'title' => ' - LW1',
      ),
      10 => 
      array (
        'value' => 'LW2',
        'title' => ' - LW2',
      ),
      11 => 
      array (
        'value' => 'LW200',
        'title' => ' - LW200',
      ),
      12 => 
      array (
        'value' => 'LW300',
        'title' => ' - LW300',
      ),
      13 => 
      array (
        'value' => 'OUTLOOK',
        'title' => 'Outlook',
      ),
      14 => 
      array (
        'value' => 'RELAY',
        'title' => 'Relay',
      ),
      15 => 
      array (
        'value' => 'SC_SERIES',
        'title' => 'SC Series (2)',
      ),
      16 => 
      array (
        'value' => 'SC1',
        'title' => ' - SC1',
      ),
      17 => 
      array (
        'value' => 'SC2',
        'title' => ' - SC2',
      ),
      18 => 
      array (
        'value' => 'SKY',
        'title' => 'Sky',
      ),
      19 => 
      array (
        'value' => 'SL_SERIES',
        'title' => 'SL Series (3)',
      ),
      20 => 
      array (
        'value' => 'SL',
        'title' => ' - SL',
      ),
      21 => 
      array (
        'value' => 'SL1',
        'title' => ' - SL1',
      ),
      22 => 
      array (
        'value' => 'SL2',
        'title' => ' - SL2',
      ),
      23 => 
      array (
        'value' => 'SW_SERIES',
        'title' => 'SW Series (2)',
      ),
      24 => 
      array (
        'value' => 'SW1',
        'title' => ' - SW1',
      ),
      25 => 
      array (
        'value' => 'SW2',
        'title' => ' - SW2',
      ),
      26 => 
      array (
        'value' => 'VUE',
        'title' => 'Vue',
      ),
      27 => 
      array (
        'value' => 'SATOTH',
        'title' => 'Other Saturn Models',
      ),
    ),
  ),
  59 => 
  array (
    'value' => 'SCION',
    'title' => 'Scion',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'SCIFRS',
        'title' => 'FR-S',
      ),
      1 => 
      array (
        'value' => 'IQ',
        'title' => 'iQ',
      ),
      2 => 
      array (
        'value' => 'TC',
        'title' => 'tC',
      ),
      3 => 
      array (
        'value' => 'XA',
        'title' => 'xA',
      ),
      4 => 
      array (
        'value' => 'XB',
        'title' => 'xB',
      ),
      5 => 
      array (
        'value' => 'XD',
        'title' => 'xD',
      ),
    ),
  ),
  60 => 
  array (
    'value' => 'SMART',
    'title' => 'smart',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'FORTWO',
        'title' => 'fortwo',
      ),
      1 => 
      array (
        'value' => 'SMOTH',
        'title' => 'Other smart Models',
      ),
    ),
  ),
  61 => 
  array (
    'value' => 'SRT',
    'title' => 'SRT',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'SRTVIPER',
        'title' => 'Viper',
      ),
    ),
  ),
  62 => 
  array (
    'value' => 'STERL',
    'title' => 'Sterling',
    'models' => 
    array (
      0 => 
      array (
        'value' => '825',
        'title' => '825',
      ),
      1 => 
      array (
        'value' => '827',
        'title' => '827',
      ),
      2 => 
      array (
        'value' => 'UNAVAILSTE',
        'title' => 'Other Sterling Models',
      ),
    ),
  ),
  63 => 
  array (
    'value' => 'SUB',
    'title' => 'Subaru',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'BAJA',
        'title' => 'Baja',
      ),
      1 => 
      array (
        'value' => 'BRAT',
        'title' => 'Brat',
      ),
      2 => 
      array (
        'value' => 'SUBBRZ',
        'title' => 'BRZ',
      ),
      3 => 
      array (
        'value' => 'FOREST',
        'title' => 'Forester',
      ),
      4 => 
      array (
        'value' => 'IMPREZ',
        'title' => 'Impreza',
      ),
      5 => 
      array (
        'value' => 'IMPWRX',
        'title' => 'Impreza WRX',
      ),
      6 => 
      array (
        'value' => 'JUSTY',
        'title' => 'Justy',
      ),
      7 => 
      array (
        'value' => 'SUBL',
        'title' => 'L Series',
      ),
      8 => 
      array (
        'value' => 'LEGACY',
        'title' => 'Legacy',
      ),
      9 => 
      array (
        'value' => 'LOYALE',
        'title' => 'Loyale',
      ),
      10 => 
      array (
        'value' => 'SUBOUTBK',
        'title' => 'Outback',
      ),
      11 => 
      array (
        'value' => 'SVX',
        'title' => 'SVX',
      ),
      12 => 
      array (
        'value' => 'B9TRIBECA',
        'title' => 'Tribeca',
      ),
      13 => 
      array (
        'value' => 'XT',
        'title' => 'XT',
      ),
      14 => 
      array (
        'value' => 'XVCRSSTREK',
        'title' => 'XV Crosstrek',
      ),
      15 => 
      array (
        'value' => 'SUBOTH',
        'title' => 'Other Subaru Models',
      ),
    ),
  ),
  64 => 
  array (
    'value' => 'SUZUKI',
    'title' => 'Suzuki',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'AERIO',
        'title' => 'Aerio',
      ),
      1 => 
      array (
        'value' => 'EQUATOR',
        'title' => 'Equator',
      ),
      2 => 
      array (
        'value' => 'ESTEEM',
        'title' => 'Esteem',
      ),
      3 => 
      array (
        'value' => 'FORENZA',
        'title' => 'Forenza',
      ),
      4 => 
      array (
        'value' => 'GRANDV',
        'title' => 'Grand Vitara',
      ),
      5 => 
      array (
        'value' => 'KIZASHI',
        'title' => 'Kizashi',
      ),
      6 => 
      array (
        'value' => 'RENO',
        'title' => 'Reno',
      ),
      7 => 
      array (
        'value' => 'SAMUR',
        'title' => 'Samurai',
      ),
      8 => 
      array (
        'value' => 'SIDE',
        'title' => 'Sidekick',
      ),
      9 => 
      array (
        'value' => 'SWIFT',
        'title' => 'Swift',
      ),
      10 => 
      array (
        'value' => 'SX4',
        'title' => 'SX4',
      ),
      11 => 
      array (
        'value' => 'VERONA',
        'title' => 'Verona',
      ),
      12 => 
      array (
        'value' => 'VITARA',
        'title' => 'Vitara',
      ),
      13 => 
      array (
        'value' => 'X90',
        'title' => 'X-90',
      ),
      14 => 
      array (
        'value' => 'XL7',
        'title' => 'XL7',
      ),
      15 => 
      array (
        'value' => 'SUZOTH',
        'title' => 'Other Suzuki Models',
      ),
    ),
  ),
  65 => 
  array (
    'value' => 'TESLA',
    'title' => 'Tesla',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'ROADSTER',
        'title' => 'Roadster',
      ),
    ),
  ),
  66 => 
  array (
    'value' => 'TOYOTA',
    'title' => 'Toyota',
    'models' => 
    array (
      0 => 
      array (
        'value' => '4RUN',
        'title' => '4Runner',
      ),
      1 => 
      array (
        'value' => 'AVALON',
        'title' => 'Avalon',
      ),
      2 => 
      array (
        'value' => 'CAMRY',
        'title' => 'Camry',
      ),
      3 => 
      array (
        'value' => 'CELICA',
        'title' => 'Celica',
      ),
      4 => 
      array (
        'value' => 'COROL',
        'title' => 'Corolla',
      ),
      5 => 
      array (
        'value' => 'CORONA',
        'title' => 'Corona',
      ),
      6 => 
      array (
        'value' => 'CRESS',
        'title' => 'Cressida',
      ),
      7 => 
      array (
        'value' => 'ECHO',
        'title' => 'Echo',
      ),
      8 => 
      array (
        'value' => 'FJCRUIS',
        'title' => 'FJ Cruiser',
      ),
      9 => 
      array (
        'value' => 'HIGHLANDER',
        'title' => 'Highlander',
      ),
      10 => 
      array (
        'value' => 'LC',
        'title' => 'Land Cruiser',
      ),
      11 => 
      array (
        'value' => 'MATRIX',
        'title' => 'Matrix',
      ),
      12 => 
      array (
        'value' => 'MR2',
        'title' => 'MR2',
      ),
      13 => 
      array (
        'value' => 'MR2SPYDR',
        'title' => 'MR2 Spyder',
      ),
      14 => 
      array (
        'value' => 'PASEO',
        'title' => 'Paseo',
      ),
      15 => 
      array (
        'value' => 'PICKUP',
        'title' => 'Pickup',
      ),
      16 => 
      array (
        'value' => 'PREVIA',
        'title' => 'Previa',
      ),
      17 => 
      array (
        'value' => 'PRIUS',
        'title' => 'Prius',
      ),
      18 => 
      array (
        'value' => 'PRIUSC',
        'title' => 'Prius C',
      ),
      19 => 
      array (
        'value' => 'PRIUSV',
        'title' => 'Prius V',
      ),
      20 => 
      array (
        'value' => 'RAV4',
        'title' => 'RAV4',
      ),
      21 => 
      array (
        'value' => 'SEQUOIA',
        'title' => 'Sequoia',
      ),
      22 => 
      array (
        'value' => 'SIENNA',
        'title' => 'Sienna',
      ),
      23 => 
      array (
        'value' => 'SOLARA',
        'title' => 'Solara',
      ),
      24 => 
      array (
        'value' => 'STARLET',
        'title' => 'Starlet',
      ),
      25 => 
      array (
        'value' => 'SUPRA',
        'title' => 'Supra',
      ),
      26 => 
      array (
        'value' => 'T100',
        'title' => 'T100',
      ),
      27 => 
      array (
        'value' => 'TACOMA',
        'title' => 'Tacoma',
      ),
      28 => 
      array (
        'value' => 'TERCEL',
        'title' => 'Tercel',
      ),
      29 => 
      array (
        'value' => 'TUNDRA',
        'title' => 'Tundra',
      ),
      30 => 
      array (
        'value' => 'TOYVAN',
        'title' => 'Van',
      ),
      31 => 
      array (
        'value' => 'VENZA',
        'title' => 'Venza',
      ),
      32 => 
      array (
        'value' => 'YARIS',
        'title' => 'Yaris',
      ),
      33 => 
      array (
        'value' => 'TOYOTH',
        'title' => 'Other Toyota Models',
      ),
    ),
  ),
  67 => 
  array (
    'value' => 'TRI',
    'title' => 'Triumph',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'TR7',
        'title' => 'TR7',
      ),
      1 => 
      array (
        'value' => 'TR8',
        'title' => 'TR8',
      ),
      2 => 
      array (
        'value' => 'TRIOTH',
        'title' => 'Other Triumph Models',
      ),
    ),
  ),
  68 => 
  array (
    'value' => 'VOLKS',
    'title' => 'Volkswagen',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'BEETLE',
        'title' => 'Beetle',
      ),
      1 => 
      array (
        'value' => 'VOLKSCAB',
        'title' => 'Cabrio',
      ),
      2 => 
      array (
        'value' => 'CAB',
        'title' => 'Cabriolet',
      ),
      3 => 
      array (
        'value' => 'CC',
        'title' => 'CC',
      ),
      4 => 
      array (
        'value' => 'CORR',
        'title' => 'Corrado',
      ),
      5 => 
      array (
        'value' => 'DASHER',
        'title' => 'Dasher',
      ),
      6 => 
      array (
        'value' => 'EOS',
        'title' => 'Eos',
      ),
      7 => 
      array (
        'value' => 'EUROVAN',
        'title' => 'Eurovan',
      ),
      8 => 
      array (
        'value' => 'VOLKSFOX',
        'title' => 'Fox',
      ),
      9 => 
      array (
        'value' => 'GLI',
        'title' => 'GLI',
      ),
      10 => 
      array (
        'value' => 'GOLFR',
        'title' => 'Golf R',
      ),
      11 => 
      array (
        'value' => 'GTI',
        'title' => 'GTI',
      ),
      12 => 
      array (
        'value' => 'GOLFANDRABBITMODELS',
        'title' => 'Golf and Rabbit Models (2)',
      ),
      13 => 
      array (
        'value' => 'GOLF',
        'title' => ' - Golf',
      ),
      14 => 
      array (
        'value' => 'RABBIT',
        'title' => ' - Rabbit',
      ),
      15 => 
      array (
        'value' => 'JET',
        'title' => 'Jetta',
      ),
      16 => 
      array (
        'value' => 'PASS',
        'title' => 'Passat',
      ),
      17 => 
      array (
        'value' => 'PHAETON',
        'title' => 'Phaeton',
      ),
      18 => 
      array (
        'value' => 'RABBITPU',
        'title' => 'Pickup',
      ),
      19 => 
      array (
        'value' => 'QUAN',
        'title' => 'Quantum',
      ),
      20 => 
      array (
        'value' => 'R32',
        'title' => 'R32',
      ),
      21 => 
      array (
        'value' => 'ROUTAN',
        'title' => 'Routan',
      ),
      22 => 
      array (
        'value' => 'SCIR',
        'title' => 'Scirocco',
      ),
      23 => 
      array (
        'value' => 'TIGUAN',
        'title' => 'Tiguan',
      ),
      24 => 
      array (
        'value' => 'TOUAREG',
        'title' => 'Touareg',
      ),
      25 => 
      array (
        'value' => 'VANAG',
        'title' => 'Vanagon',
      ),
      26 => 
      array (
        'value' => 'VWOTH',
        'title' => 'Other Volkswagen Models',
      ),
    ),
  ),
  69 => 
  array (
    'value' => 'VOLVO',
    'title' => 'Volvo',
    'models' => 
    array (
      0 => 
      array (
        'value' => '240',
        'title' => '240',
      ),
      1 => 
      array (
        'value' => '260',
        'title' => '260',
      ),
      2 => 
      array (
        'value' => '740',
        'title' => '740',
      ),
      3 => 
      array (
        'value' => '760',
        'title' => '760',
      ),
      4 => 
      array (
        'value' => '780',
        'title' => '780',
      ),
      5 => 
      array (
        'value' => '850',
        'title' => '850',
      ),
      6 => 
      array (
        'value' => '940',
        'title' => '940',
      ),
      7 => 
      array (
        'value' => '960',
        'title' => '960',
      ),
      8 => 
      array (
        'value' => 'C30',
        'title' => 'C30',
      ),
      9 => 
      array (
        'value' => 'C70',
        'title' => 'C70',
      ),
      10 => 
      array (
        'value' => 'S40',
        'title' => 'S40',
      ),
      11 => 
      array (
        'value' => 'S60',
        'title' => 'S60',
      ),
      12 => 
      array (
        'value' => 'S70',
        'title' => 'S70',
      ),
      13 => 
      array (
        'value' => 'S80',
        'title' => 'S80',
      ),
      14 => 
      array (
        'value' => 'S90',
        'title' => 'S90',
      ),
      15 => 
      array (
        'value' => 'V40',
        'title' => 'V40',
      ),
      16 => 
      array (
        'value' => 'V50',
        'title' => 'V50',
      ),
      17 => 
      array (
        'value' => 'V70',
        'title' => 'V70',
      ),
      18 => 
      array (
        'value' => 'V90',
        'title' => 'V90',
      ),
      19 => 
      array (
        'value' => 'XC60',
        'title' => 'XC60',
      ),
      20 => 
      array (
        'value' => 'XC',
        'title' => 'XC70',
      ),
      21 => 
      array (
        'value' => 'XC90',
        'title' => 'XC90',
      ),
      22 => 
      array (
        'value' => 'VOLOTH',
        'title' => 'Other Volvo Models',
      ),
    ),
  ),
  70 => 
  array (
    'value' => 'YUGO',
    'title' => 'Yugo',
    'models' => 
    array (
      0 => 
      array (
        'value' => 'GV',
        'title' => 'GV',
      ),
      1 => 
      array (
        'value' => 'GVC',
        'title' => 'GVC',
      ),
      2 => 
      array (
        'value' => 'GVL',
        'title' => 'GVL',
      ),
      3 => 
      array (
        'value' => 'GVS',
        'title' => 'GVS',
      ),
      4 => 
      array (
        'value' => 'GVX',
        'title' => 'GVX',
      ),
      5 => 
      array (
        'value' => 'YUOTH',
        'title' => 'Other Yugo Models',
      ),
    ),
  ),
);